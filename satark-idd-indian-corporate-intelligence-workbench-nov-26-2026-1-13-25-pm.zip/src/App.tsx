import { FormEvent, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowRight,
  Building2,
  FileText,
  GitBranch,
  Hash,
  LayoutGrid,
  Plus,
  Trash2,
  User,
} from 'lucide-react';
import { AnalystNotesPanel } from './components/AnalystNotesPanel';
import { OsintPanel } from './components/OsintPanel';
import { RelationshipMapperPanel } from './components/RelationshipMapperPanel';
import {
  AnalystNotes,
  DossierRecord,
  EntityDirectorLink,
  InvestigationSubject,
  InvestigationType,
} from './types/investigation';
import {
  analyzeIdentifier,
  buildOsintQueries,
} from './utils/osintBuilder';

const STORAGE_KEY_CASES = 'satark_idd_saved_dossiers_v1';
const STORAGE_KEY_ACTIVE_ID = 'satark_idd_active_dossier_id_v1';

type WorkspaceTab = 'workbench' | 'mapper';

const COVERAGE_VERTICALS = [
  {
    code: '01',
    name: 'SEBI Enforcement Orders',
    scope: 'WTM debarment orders, adjudication penalties, SAT appeals, and insider trading notices.',
  },
  {
    code: '02',
    name: 'NCLT Insolvency Filings',
    scope: 'IBC Section 7/9/10 petitions, CIRP admissions, IBBI moratoriums, and NCLAT appeals.',
  },
  {
    code: '03',
    name: 'e-Courts Litigation',
    scope: 'High Court and District Court dockets, Indian Kanoon judgments, and Section 138 NI Act suits.',
  },
  {
    code: '04',
    name: 'RBI Wilful Defaulters',
    scope: 'TransUnion CIBIL suit-filed accounts, DRT recovery actions, SARFAESI notices, and NPAs.',
  },
  {
    code: '05',
    name: 'ED / CBI News',
    scope: 'Enforcement Directorate PMLA/FEMA attachments, CBI FIRs, SFIO probes, and EOW cases.',
  },
  {
    code: '06',
    name: 'MCA21 Corporate Records',
    scope: 'DIN/CIN signatory master data, Section 164(2) disqualifications, charges, and STK-7 strike-offs.',
  },
];

function createCaseReference(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  const suffix = String(Math.floor(100 + Math.random() * 900));
  return `IDD-IND-${y}${m}${d}-${suffix}`;
}

function createEmptyNotes(): AnalystNotes {
  return {
    caseReference: createCaseReference(),
    analystName: '',
    riskRating: 'Clear',
    riskScores: {
      corporateGovernance: 0,
      regulatoryCompliance: 0,
      litigationInsolvency: 0,
      adverseMediaEnforcement: 0,
    },
    corporateBackground: '',
    regulatoryLitigationRedFlags: '',
    adverseMediaFindings: '',
    citations: [],
  };
}

function normalizeRecord(raw: DossierRecord): DossierRecord {
  const empty = createEmptyNotes();
  return {
    ...raw,
    investigationType: raw.investigationType ?? 'pre_deal_pe',
    entityLinks: Array.isArray(raw.entityLinks) ? raw.entityLinks : [],
    reviewedLinkIds: Array.isArray(raw.reviewedLinkIds) ? raw.reviewedLinkIds : [],
    notes: {
      ...empty,
      ...raw.notes,
      riskScores: {
        ...empty.riskScores,
        ...(raw.notes?.riskScores ?? {}),
      },
      citations: Array.isArray(raw.notes?.citations) ? raw.notes.citations : [],
    },
  };
}

function makeDossierKey(subject: InvestigationSubject): string {
  return [
    subject.subjectName.trim().toLowerCase(),
    subject.companyName.trim().toLowerCase(),
    subject.dinCin.trim().toLowerCase(),
  ].join('|');
}

function formatTimeNow(): string {
  return new Date().toLocaleTimeString('en-IN', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });
}

function buildSampleDossierData(): {
  subject: InvestigationSubject;
  notes: Partial<AnalystNotes>;
  entityLinks: EntityDirectorLink[];
} {
  const today = new Date().toISOString().slice(0, 10);
  return {
    subject: {
      subjectName: 'Ramesh Sharma',
      companyName: 'ABC Infra Pvt Ltd',
      dinCin: 'U45200MH2010PTC201234',
    },
    notes: {
      riskRating: 'Medium',
      riskScores: {
        corporateGovernance: 2,
        regulatoryCompliance: 1,
        litigationInsolvency: 1,
        adverseMediaEnforcement: 0,
      },
      citations: [
        {
          id: 'sample_cit_1',
          title: 'MCA21 Signatory & Charge Master Data — ABC Infra Pvt Ltd',
          url: 'https://www.mca.gov.in/mcafoportal/viewCompanyMasterData.do',
          dateAccessed: today,
          reliability: 'Primary Regulatory',
        },
        {
          id: 'sample_cit_2',
          title: 'NCLT Mumbai Bench Cause List & IBC Search',
          url: 'https://nclt.gov.in/order-judgement',
          dateAccessed: today,
          reliability: 'Primary Regulatory',
        },
      ],
    },
    entityLinks: [
      {
        id: 'smp_1',
        companyName: 'ABC Infra Pvt Ltd',
        directorName: 'Ramesh Sharma',
        din: '01234567',
        registeredAddress: '402 Peninsula Corporate Park, Lower Parel, Mumbai 400013',
      },
      {
        id: 'smp_2',
        companyName: 'ABC Infra Pvt Ltd',
        directorName: 'Vikram Mehta',
        din: '02948112',
        registeredAddress: '402 Peninsula Corporate Park, Lower Parel, Mumbai 400013',
      },
      {
        id: 'smp_3',
        companyName: 'Horizon Buildcon LLP',
        directorName: 'Ramesh Sharma',
        din: '01234567',
        registeredAddress: '402 Peninsula Corporate Park, Lower Parel, Mumbai 400013',
      },
      {
        id: 'smp_4',
        companyName: 'Horizon Buildcon LLP',
        directorName: 'Neha Kulkarni',
        din: '07812450',
        registeredAddress: '402 Peninsula Corporate Park, Lower Parel, Mumbai 400013',
      },
      {
        id: 'smp_5',
        companyName: 'Deccan Logistics Ventures Pvt Ltd',
        directorName: 'Ramesh Sharma',
        din: '01234567',
        registeredAddress: '18 MG Road, Indiranagar, Bengaluru 560008',
      },
      {
        id: 'smp_6',
        companyName: 'Apex Realty Holdings Pvt Ltd',
        directorName: 'Vikram Mehta',
        din: '02948112',
        registeredAddress: 'Suite 12, Nariman Bhavan, Nariman Point, Mumbai 400021',
      },
    ],
  };
}

export default function App() {
  const subjectInputRef = useRef<HTMLInputElement>(null);

  const [subjectNameInput, setSubjectNameInput] = useState('');
  const [companyNameInput, setCompanyNameInput] = useState('');
  const [dinCinInput, setDinCinInput] = useState('');
  const [validationError, setValidationError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<WorkspaceTab>('workbench');

  const [savedCases, setSavedCases] = useState<DossierRecord[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_CASES);
      const parsed = raw ? (JSON.parse(raw) as DossierRecord[]) : [];
      return parsed.map(normalizeRecord);
    } catch {
      return [];
    }
  });

  const [activeDossierId, setActiveDossierId] = useState<string | null>(() => {
    try {
      return localStorage.getItem(STORAGE_KEY_ACTIVE_ID);
    } catch {
      return null;
    }
  });

  const [lastSavedAt, setLastSavedAt] = useState<string | null>(null);

  const activeDossier = useMemo(
    () => savedCases.find((c) => c.id === activeDossierId) ?? null,
    [savedCases, activeDossierId]
  );

  useEffect(() => {
    if (activeDossier && !subjectNameInput && !companyNameInput && !dinCinInput) {
      setSubjectNameInput(activeDossier.subject.subjectName);
      setCompanyNameInput(activeDossier.subject.companyName);
      setDinCinInput(activeDossier.subject.dinCin);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_CASES, JSON.stringify(savedCases));
    } catch {
      // Ignore storage quota issues
    }
  }, [savedCases]);

  useEffect(() => {
    try {
      if (activeDossierId) {
        localStorage.setItem(STORAGE_KEY_ACTIVE_ID, activeDossierId);
      } else {
        localStorage.removeItem(STORAGE_KEY_ACTIVE_ID);
      }
    } catch {
      // Ignore storage issues
    }
  }, [activeDossierId]);

  const osintItems = useMemo(() => {
    if (!activeDossier) return [];
    return buildOsintQueries(
      activeDossier.subject,
      activeDossier.investigationType
    );
  }, [activeDossier]);

  const identifierMeta = useMemo(() => {
    if (!activeDossier) return null;
    return analyzeIdentifier(activeDossier.subject.dinCin);
  }, [activeDossier]);

  const openOrCreateDossier = (
    subject: InvestigationSubject,
    seedData?: {
      notes?: Partial<AnalystNotes>;
      entityLinks?: EntityDirectorLink[];
    }
  ) => {
    const cleanSubject: InvestigationSubject = {
      subjectName: subject.subjectName.trim(),
      companyName: subject.companyName.trim(),
      dinCin: subject.dinCin.trim().toUpperCase(),
    };

    const key = makeDossierKey(cleanSubject);
    const existing = savedCases.find((item) => makeDossierKey(item.subject) === key);

    if (existing) {
      setActiveDossierId(existing.id);
      setSubjectNameInput(existing.subject.subjectName);
      setCompanyNameInput(existing.subject.companyName);
      setDinCinInput(existing.subject.dinCin);
      setLastSavedAt(formatTimeNow());
      return;
    }

    const nowIso = new Date().toISOString();
    const baseNotes = createEmptyNotes();
    const newRecord: DossierRecord = {
      id: `dossier_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      subject: cleanSubject,
      investigationType: 'pre_deal_pe',
      notes: {
        ...baseNotes,
        ...(seedData?.notes ?? {}),
      },
      reviewedLinkIds: [],
      entityLinks: seedData?.entityLinks ?? [],
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    setSavedCases((prev) => [newRecord, ...prev]);
    setActiveDossierId(newRecord.id);
    setSubjectNameInput(cleanSubject.subjectName);
    setCompanyNameInput(cleanSubject.companyName);
    setDinCinInput(cleanSubject.dinCin);
    setLastSavedAt(formatTimeNow());
  };

  const handleGenerateSubmit = (e: FormEvent) => {
    e.preventDefault();
    const hasInput =
      subjectNameInput.trim().length > 0 ||
      companyNameInput.trim().length > 0 ||
      dinCinInput.trim().length > 0;

    if (!hasInput) {
      setValidationError(
        'Enter at least a Subject Name, Company Name, or DIN/CIN to build an investigation dossier.'
      );
      return;
    }

    setValidationError(null);
    openOrCreateDossier({
      subjectName: subjectNameInput,
      companyName: companyNameInput,
      dinCin: dinCinInput,
    });
  };

  const handleLoadSample = () => {
    setValidationError(null);
    const sample = buildSampleDossierData();
    openOrCreateDossier(sample.subject, {
      notes: sample.notes,
      entityLinks: sample.entityLinks,
    });
  };

  const handleNewInvestigation = () => {
    setActiveDossierId(null);
    setSubjectNameInput('');
    setCompanyNameInput('');
    setDinCinInput('');
    setValidationError(null);
    setLastSavedAt(null);
    setActiveTab('workbench');
    setTimeout(() => subjectInputRef.current?.focus(), 0);
  };

  const handleChangeInvestigationType = (type: InvestigationType) => {
    if (!activeDossierId) return;
    setSavedCases((prev) =>
      prev.map((record) =>
        record.id === activeDossierId
          ? {
              ...record,
              investigationType: type,
              updatedAt: new Date().toISOString(),
            }
          : record
      )
    );
    setLastSavedAt(formatTimeNow());
  };

  const handleUpdateNotes = (updated: Partial<AnalystNotes>) => {
    if (!activeDossierId) return;
    setSavedCases((prev) =>
      prev.map((record) =>
        record.id === activeDossierId
          ? {
              ...record,
              notes: { ...record.notes, ...updated },
              updatedAt: new Date().toISOString(),
            }
          : record
      )
    );
    setLastSavedAt(formatTimeNow());
  };

  const handleUpdateEntityLinks = (links: EntityDirectorLink[]) => {
    if (!activeDossierId) return;
    setSavedCases((prev) =>
      prev.map((record) =>
        record.id === activeDossierId
          ? {
              ...record,
              entityLinks: links,
              updatedAt: new Date().toISOString(),
            }
          : record
      )
    );
    setLastSavedAt(formatTimeNow());
  };

  const handleAppendNexusToMemo = (summaryText: string) => {
    if (!activeDossier) return;
    const current = activeDossier.notes.corporateBackground.trim();
    const next = current ? `${current}\n\n${summaryText}` : summaryText;
    handleUpdateNotes({ corporateBackground: next });
  };

  const handleToggleReviewed = (linkId: string) => {
    if (!activeDossierId) return;
    setSavedCases((prev) =>
      prev.map((record) => {
        if (record.id !== activeDossierId) return record;
        const exists = record.reviewedLinkIds.includes(linkId);
        return {
          ...record,
          reviewedLinkIds: exists
            ? record.reviewedLinkIds.filter((id) => id !== linkId)
            : [...record.reviewedLinkIds, linkId],
          updatedAt: new Date().toISOString(),
        };
      })
    );
    setLastSavedAt(formatTimeNow());
  };

  const handleMarkReviewed = (linkId: string) => {
    if (!activeDossierId) return;
    setSavedCases((prev) =>
      prev.map((record) => {
        if (record.id !== activeDossierId) return record;
        if (record.reviewedLinkIds.includes(linkId)) return record;
        return {
          ...record,
          reviewedLinkIds: [...record.reviewedLinkIds, linkId],
          updatedAt: new Date().toISOString(),
        };
      })
    );
    setLastSavedAt(formatTimeNow());
  };

  const handleResetReviewed = () => {
    if (!activeDossierId) return;
    setSavedCases((prev) =>
      prev.map((record) =>
        record.id === activeDossierId
          ? { ...record, reviewedLinkIds: [], updatedAt: new Date().toISOString() }
          : record
      )
    );
    setLastSavedAt(formatTimeNow());
  };

  const handleSelectSavedCase = (record: DossierRecord) => {
    setValidationError(null);
    setActiveDossierId(record.id);
    setSubjectNameInput(record.subject.subjectName);
    setCompanyNameInput(record.subject.companyName);
    setDinCinInput(record.subject.dinCin);
    setLastSavedAt(formatTimeNow());
  };

  const handleDeleteSavedCase = (id: string) => {
    setSavedCases((prev) => prev.filter((c) => c.id !== id));
    if (activeDossierId === id) {
      setActiveDossierId(null);
      setSubjectNameInput('');
      setCompanyNameInput('');
      setDinCinInput('');
      setLastSavedAt(null);
    }
  };

  return (
    <div className="min-h-screen bg-[#090D16] text-slate-200 flex flex-col">
      {/* Top Bar Contract: 3 zones (wordmark — single-line links — 1 primary action) */}
      <header className="border-b border-slate-800/80 bg-[#090D16]/95 backdrop-blur-sm sticky top-0 z-30">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
          <a
            href="#intake"
            className="text-lg font-bold tracking-tight text-slate-100 whitespace-nowrap shrink-0"
          >
            OpenVett IDD
          </a>

          <nav
            aria-label="Primary sections"
            className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-400"
          >
            <a
              href="#intake"
              className="hover:text-slate-100 transition-colors whitespace-nowrap shrink-0"
            >
              Subject Intake
            </a>
            <a
              href={activeDossier ? '#workspace-tabs' : '#coverage'}
              onClick={() => {
                if (activeDossier) setActiveTab('workbench');
              }}
              className="hover:text-slate-100 transition-colors whitespace-nowrap shrink-0"
            >
              OSINT & Memo
            </a>
            <a
              href={activeDossier ? '#workspace-tabs' : '#coverage'}
              onClick={() => {
                if (activeDossier) setActiveTab('mapper');
              }}
              className="hover:text-slate-100 transition-colors whitespace-nowrap shrink-0"
            >
              Relationship Mapper
            </a>
            <a
              href="#case-archive"
              className="hover:text-slate-100 transition-colors whitespace-nowrap shrink-0"
            >
              Saved Dossiers
            </a>
          </nav>

          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={handleNewInvestigation}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-slate-100 bg-[#131B29] border border-slate-700/80 rounded-lg hover:bg-[#192336] hover:border-slate-600 transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
            >
              <Plus className="w-3.5 h-3.5 text-blue-400" aria-hidden="true" />
              New Investigation
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 w-full max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Top Investigation Intake Section */}
        <section
          id="intake"
          aria-labelledby="intake-heading"
          className="bg-[#111826] border border-slate-800/90 rounded-xl p-6 lg:p-7"
        >
          <div className="flex flex-wrap items-end justify-between gap-4 mb-6">
            <div className="max-w-2xl">
              <h1
                id="intake-heading"
                className="text-2xl sm:text-[28px] font-bold text-slate-100 tracking-tight text-balance"
              >
                OpenVett IDD
              </h1>
              <p className="mt-1.5 text-sm text-slate-400 leading-relaxed">
                Bespoke Indian Corporate Intelligence & OSINT Workbench
              </p>
            </div>

            <button
              type="button"
              onClick={handleLoadSample}
              className="text-xs font-medium text-blue-400 hover:text-blue-300 transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded px-2 py-1"
            >
              Load OpenVett IDD sample: Ramesh Sharma · ABC Infra Pvt Ltd
            </button>
          </div>

          <form onSubmit={handleGenerateSubmit} noValidate>
            <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
              <div className="md:col-span-4">
                <label
                  htmlFor="subject-name-input"
                  className="block text-xs font-medium text-slate-300 mb-1.5"
                >
                  Subject Name
                </label>
                <div className="relative">
                  <User
                    className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                    aria-hidden="true"
                  />
                  <input
                    ref={subjectInputRef}
                    id="subject-name-input"
                    type="text"
                    value={subjectNameInput}
                    onChange={(e) => {
                      setSubjectNameInput(e.target.value);
                      if (validationError) setValidationError(null);
                    }}
                    placeholder="e.g., Ramesh Sharma"
                    className="w-full bg-[#090D16] border border-slate-800 rounded-lg pl-10 pr-3.5 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-blue-500/80 focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>
              </div>

              <div className="md:col-span-4">
                <label
                  htmlFor="company-name-input"
                  className="block text-xs font-medium text-slate-300 mb-1.5"
                >
                  Company Name
                </label>
                <div className="relative">
                  <Building2
                    className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                    aria-hidden="true"
                  />
                  <input
                    id="company-name-input"
                    type="text"
                    value={companyNameInput}
                    onChange={(e) => {
                      setCompanyNameInput(e.target.value);
                      if (validationError) setValidationError(null);
                    }}
                    placeholder="e.g., ABC Infra Pvt Ltd"
                    className="w-full bg-[#090D16] border border-slate-800 rounded-lg pl-10 pr-3.5 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-blue-500/80 focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>
              </div>

              <div className="md:col-span-4 lg:col-span-2">
                <label
                  htmlFor="din-cin-input"
                  className="block text-xs font-medium text-slate-300 mb-1.5"
                >
                  Optional DIN / CIN
                </label>
                <div className="relative">
                  <Hash
                    className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                    aria-hidden="true"
                  />
                  <input
                    id="din-cin-input"
                    type="text"
                    value={dinCinInput}
                    onChange={(e) => {
                      setDinCinInput(e.target.value);
                      if (validationError) setValidationError(null);
                    }}
                    placeholder="01234567 / CIN"
                    className="w-full bg-[#090D16] border border-slate-800 rounded-lg pl-10 pr-3.5 py-2.5 text-sm font-mono text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-blue-500/80 focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>
              </div>

              <div className="md:col-span-12 lg:col-span-2">
                <button
                  type="submit"
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
                >
                  Generate Investigation Dossier
                </button>
              </div>
            </div>

            {validationError && (
              <p role="alert" className="mt-3 text-xs font-medium text-rose-400">
                {validationError}
              </p>
            )}
          </form>
        </section>

        {/* Active Investigation Dossier Workspace */}
        {activeDossier ? (
          <div id="workspace-tabs" className="space-y-6">
            {/* Unboxed Active Subject Context Strip + Workspace View Switcher */}
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800/80 pb-4">
              <div className="space-y-1">
                <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm">
                  <span className="font-semibold text-blue-400">
                    OpenVett IDD Dossier
                  </span>
                  <span className="text-slate-600" aria-hidden="true">
                    ·
                  </span>
                  <span className="font-semibold text-slate-100">
                    {activeDossier.subject.companyName ||
                      activeDossier.subject.subjectName ||
                      'Active Target'}
                  </span>
                  {activeDossier.subject.companyName &&
                    activeDossier.subject.subjectName && (
                      <>
                        <span className="text-slate-600" aria-hidden="true">
                          ·
                        </span>
                        <span className="text-slate-300">
                          Subject: {activeDossier.subject.subjectName}
                        </span>
                      </>
                    )}
                  {identifierMeta && identifierMeta.type !== 'None' && (
                    <>
                      <span className="text-slate-600" aria-hidden="true">
                        ·
                      </span>
                      <span className="font-mono text-xs text-slate-400">
                        {identifierMeta.label}
                      </span>
                    </>
                  )}
                </div>

                <div className="flex items-center gap-3 text-xs text-slate-500 font-mono tabular-nums">
                  <span>Ref: {activeDossier.notes.caseReference || 'Unassigned'}</span>
                  <span aria-hidden="true">·</span>
                  <span>{activeDossier.notes.citations.length} citations</span>
                  <span aria-hidden="true">·</span>
                  <span>{activeDossier.entityLinks.length} MCA21 links</span>
                </div>
              </div>

              {/* Workspace Tabs */}
              <div
                role="tablist"
                aria-label="Investigation workspace tabs"
                className="flex items-center gap-1 p-1 bg-[#111826] border border-slate-800 rounded-lg shrink-0"
              >
                <button
                  type="button"
                  role="tab"
                  aria-selected={activeTab === 'workbench'}
                  onClick={() => setActiveTab('workbench')}
                  className={`inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                    activeTab === 'workbench'
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-400 hover:text-slate-100'
                  }`}
                >
                  <LayoutGrid className="w-3.5 h-3.5" aria-hidden="true" />
                  OSINT & Analyst Memo
                </button>
                <button
                  type="button"
                  role="tab"
                  aria-selected={activeTab === 'mapper'}
                  onClick={() => setActiveTab('mapper')}
                  className={`inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                    activeTab === 'mapper'
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-400 hover:text-slate-100'
                  }`}
                >
                  <GitBranch className="w-3.5 h-3.5" aria-hidden="true" />
                  Entity & Director Mapper ({activeDossier.entityLinks.length})
                </button>
              </div>
            </div>

            {/* Tab 1: Dual-Panel Investigation Workbench */}
            {activeTab === 'workbench' ? (
              <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
                <div className="xl:col-span-6">
                  <OsintPanel
                    items={osintItems}
                    investigationType={activeDossier.investigationType}
                    onChangeInvestigationType={handleChangeInvestigationType}
                    reviewedIds={activeDossier.reviewedLinkIds}
                    onToggleReviewed={handleToggleReviewed}
                    onMarkReviewed={handleMarkReviewed}
                    onResetReviewed={handleResetReviewed}
                  />
                </div>

                <div className="xl:col-span-6">
                  <AnalystNotesPanel
                    subject={activeDossier.subject}
                    investigationType={activeDossier.investigationType}
                    notes={activeDossier.notes}
                    onChangeNotes={handleUpdateNotes}
                    osintItems={osintItems}
                    reviewedIds={activeDossier.reviewedLinkIds}
                    lastSavedAt={lastSavedAt}
                  />
                </div>
              </div>
            ) : (
              /* Tab 2: Entity & Director Relationship Mapper */
              <RelationshipMapperPanel
                subject={activeDossier.subject}
                entityLinks={activeDossier.entityLinks}
                onUpdateEntityLinks={handleUpdateEntityLinks}
                onAppendFindingsToMemo={handleAppendNexusToMemo}
              />
            )}
          </div>
        ) : (
          /* Initial Empty State before generating dossier */
          <section
            id="coverage"
            aria-labelledby="coverage-heading"
            className="bg-[#111826] border border-slate-800/90 rounded-xl p-6 lg:p-8"
          >
            <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-slate-800/80">
              <div>
                <h2
                  id="coverage-heading"
                  className="text-lg font-semibold text-slate-100"
                >
                  OpenVett IDD · Sample Dossier & Screening Scope
                </h2>
                <p className="mt-1 text-sm text-slate-400">
                  Enter a subject name, corporate entity, or DIN/CIN above and click Generate Investigation Dossier to unlock targeted OSINT queries, relationship mapping, and structured memo notes.
                </p>
              </div>
              <button
                type="button"
                onClick={handleLoadSample}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-slate-100 bg-[#090D16] border border-slate-700 rounded-lg hover:border-slate-500 transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
              >
                Load OpenVett IDD Sample Dossier
                <ArrowRight className="w-3.5 h-3.5 text-blue-400" aria-hidden="true" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-6 pt-6">
              {COVERAGE_VERTICALS.map((vertical) => (
                <div key={vertical.code} className="space-y-1.5">
                  <h3 className="text-sm font-semibold text-slate-100">
                    {vertical.code}. {vertical.name}
                  </h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {vertical.scope}
                  </p>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Saved Investigation Dossiers Archive */}
        <section
          id="case-archive"
          aria-labelledby="archive-heading"
          className="bg-[#111826] border border-slate-800/90 rounded-xl overflow-hidden"
        >
          <div className="px-6 py-4 border-b border-slate-800/80 flex items-center justify-between gap-4">
            <div>
              <h2
                id="archive-heading"
                className="text-sm font-semibold text-slate-100"
              >
                Saved Investigation Dossiers
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Stored locally in your browser so notes, citations, MCA21 graphs, and checklists persist across sessions.
              </p>
            </div>
            <span className="text-xs font-mono tabular-nums text-slate-500 shrink-0">
              {savedCases.length} {savedCases.length === 1 ? 'case' : 'cases'}
            </span>
          </div>

          {savedCases.length === 0 ? (
            <div className="px-6 py-8 text-center">
              <FileText className="w-5 h-5 text-slate-600 mx-auto mb-2" aria-hidden="true" />
              <p className="text-xs text-slate-400">
                No saved dossiers yet. Generated dossiers appear here automatically.
              </p>
            </div>
          ) : (
            <div className="divide-y divide-slate-800/80">
              {savedCases.map((record) => {
                const isActive = record.id === activeDossierId;
                const title =
                  [record.subject.subjectName, record.subject.companyName]
                    .filter(Boolean)
                    .join(' · ') || record.subject.dinCin;

                return (
                  <div
                    key={record.id}
                    className={`px-6 py-3.5 flex flex-wrap items-center justify-between gap-4 transition-colors ${
                      isActive ? 'bg-[#151F32]' : 'hover:bg-[#131B2A]'
                    }`}
                  >
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-x-2.5 gap-y-0.5">
                        <button
                          type="button"
                          onClick={() => handleSelectSavedCase(record)}
                          className="text-sm font-medium text-slate-100 hover:text-blue-400 transition-colors text-left cursor-pointer"
                        >
                          {title}
                        </button>
                        {isActive && (
                          <span className="text-xs font-medium text-blue-400">
                            · Active
                          </span>
                        )}
                      </div>
                      <div className="mt-0.5 flex flex-wrap items-center gap-x-2 text-xs text-slate-500 font-mono tabular-nums">
                        <span>{record.notes.caseReference}</span>
                        <span aria-hidden="true">·</span>
                        <span>Risk: {record.notes.riskRating}</span>
                        <span aria-hidden="true">·</span>
                        <span>{record.reviewedLinkIds.length}/12 checks</span>
                        <span aria-hidden="true">·</span>
                        <span>{record.notes.citations.length} citations</span>
                        <span aria-hidden="true">·</span>
                        <span>{record.entityLinks.length} links</span>
                        {record.subject.dinCin && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span>{record.subject.dinCin}</span>
                          </>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {!isActive && (
                        <button
                          type="button"
                          onClick={() => handleSelectSavedCase(record)}
                          className="px-3 py-1.5 text-xs font-medium text-slate-200 bg-[#090D16] border border-slate-700/80 rounded-md hover:border-slate-500 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                        >
                          Open Dossier
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => handleDeleteSavedCase(record.id)}
                        aria-label={`Delete dossier for ${title}`}
                        className="p-1.5 text-slate-500 hover:text-rose-400 transition-colors rounded-md cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
                      >
                        <Trash2 className="w-4 h-4" aria-hidden="true" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </main>

      <footer className="border-t border-slate-800/80 mt-12">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-5 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-500">
          <span>Prepared via OpenVett IDD — Analyst OSINT & Regulatory Screening Workbench</span>
          <span>All queries execute directly against Google Search in your browser · Notes stored locally</span>
        </div>
      </footer>
    </div>
  );
}
