import { FormEvent, useState } from 'react';
import {
  Check,
  ExternalLink,
  FileDown,
  ListPlus,
  Plus,
  Trash2,
} from 'lucide-react';
import {
  AnalystNotes,
  InvestigationSubject,
  InvestigationType,
  OsintQueryItem,
  RiskDimensionScore,
  RiskRating,
  RiskScoringMatrix,
  SourceCitation,
  SourceReliability,
} from '../types/investigation';
import { exportInvestigationMemoDocx } from '../utils/docxExporter';

interface AnalystNotesPanelProps {
  subject: InvestigationSubject;
  investigationType: InvestigationType;
  notes: AnalystNotes;
  onChangeNotes: (updated: Partial<AnalystNotes>) => void;
  osintItems: OsintQueryItem[];
  reviewedIds: string[];
  lastSavedAt: string | null;
}

const RISK_OPTIONS: { value: RiskRating; label: string; activeClass: string }[] = [
  {
    value: 'Clear',
    label: 'Clear',
    activeClass: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40',
  },
  {
    value: 'Low',
    label: 'Low Risk',
    activeClass: 'bg-sky-500/15 text-sky-300 border-sky-500/40',
  },
  {
    value: 'Medium',
    label: 'Medium Risk',
    activeClass: 'bg-amber-500/15 text-amber-300 border-amber-500/40',
  },
  {
    value: 'High',
    label: 'High / Red Flag',
    activeClass: 'bg-rose-500/15 text-rose-300 border-rose-500/40',
  },
];

const RISK_DIMENSIONS: {
  key: keyof RiskScoringMatrix;
  label: string;
}[] = [
  { key: 'corporateGovernance', label: 'MCA21 & Governance' },
  { key: 'regulatoryCompliance', label: 'SEBI / RBI Compliance' },
  { key: 'litigationInsolvency', label: 'NCLT & Litigation' },
  { key: 'adverseMediaEnforcement', label: 'ED / CBI / Adverse Media' },
];

const SCORE_LEVELS: { value: RiskDimensionScore; label: string }[] = [
  { value: 0, label: '0' },
  { value: 1, label: '1' },
  { value: 2, label: '2' },
  { value: 3, label: '3' },
];

const RELIABILITY_OPTIONS: SourceReliability[] = [
  'Primary Regulatory',
  'Reputable Media',
  'Unverified',
];

const SECTION_PROMPTS = {
  corporateBackground: [
    '- MCA21 Entity Status & Incorporation Date: ',
    '- Registered Office & Operational Footprint: ',
    '- Key Management / DIN Directorship Linkages: ',
    '- Shareholding & Related-Party Observations: ',
  ].join('\n'),
  regulatoryLitigationRedFlags: [
    '- SEBI Enforcement / SAT Orders: ',
    '- NCLT / IBBI Insolvency & IBC Filings: ',
    '- e-Courts / High Court / Section 138 NI Act Litigation: ',
    '- RBI Wilful Defaulter / CIBIL / DRT Filings: ',
    '- MCA21 Compliance (Sec 164(2) / STK-7 / Open Charges): ',
  ].join('\n'),
  adverseMediaFindings: [
    '- ED (PMLA / FEMA) or CBI / SFIO / EOW Probes: ',
    '- Financial Press & Investigative Media Coverage: ',
    '- Politically Exposed Person (PEP) / Sanctions Nexus: ',
    '- Overall Reputational Assessment: ',
  ].join('\n'),
};

function countWords(text: string): number {
  const trimmed = text.trim();
  if (!trimmed) return 0;
  return trimmed.split(/\s+/).length;
}

function todayIsoDate(): string {
  return new Date().toISOString().slice(0, 10);
}

function getSuggestedRating(score: number): RiskRating {
  if (score === 0) return 'Clear';
  if (score <= 3) return 'Low';
  if (score <= 7) return 'Medium';
  return 'High';
}

function reliabilityTextClass(reliability: SourceReliability): string {
  if (reliability === 'Primary Regulatory') return 'text-emerald-400';
  if (reliability === 'Reputable Media') return 'text-sky-400';
  return 'text-amber-400';
}

export function AnalystNotesPanel({
  subject,
  investigationType,
  notes,
  onChangeNotes,
  osintItems,
  reviewedIds,
  lastSavedAt,
}: AnalystNotesPanelProps) {
  const [isExporting, setIsExporting] = useState(false);
  const [exportStatus, setExportStatus] = useState<'idle' | 'done' | 'error'>('idle');

  const [newCitationTitle, setNewCitationTitle] = useState('');
  const [newCitationUrl, setNewCitationUrl] = useState('');
  const [newCitationDate, setNewCitationDate] = useState(todayIsoDate);
  const [newCitationReliability, setNewCitationReliability] =
    useState<SourceReliability>('Primary Regulatory');
  const [citationError, setCitationError] = useState<string | null>(null);

  const riskScores: RiskScoringMatrix = notes.riskScores ?? {
    corporateGovernance: 0,
    regulatoryCompliance: 0,
    litigationInsolvency: 0,
    adverseMediaEnforcement: 0,
  };
  const citations = notes.citations ?? [];

  const compositeScore =
    riskScores.corporateGovernance +
    riskScores.regulatoryCompliance +
    riskScores.litigationInsolvency +
    riskScores.adverseMediaEnforcement;

  const totalWords =
    countWords(notes.corporateBackground) +
    countWords(notes.regulatoryLitigationRedFlags) +
    countWords(notes.adverseMediaFindings);

  const handleScoreChange = (
    dimension: keyof RiskScoringMatrix,
    value: RiskDimensionScore
  ) => {
    const updatedScores = { ...riskScores, [dimension]: value };
    const nextComposite =
      updatedScores.corporateGovernance +
      updatedScores.regulatoryCompliance +
      updatedScores.litigationInsolvency +
      updatedScores.adverseMediaEnforcement;
    onChangeNotes({
      riskScores: updatedScores,
      riskRating: getSuggestedRating(nextComposite),
    });
  };

  const handleInsertPrompt = (
    field: 'corporateBackground' | 'regulatoryLitigationRedFlags' | 'adverseMediaFindings'
  ) => {
    const existing = notes[field].trim();
    const template = SECTION_PROMPTS[field];
    onChangeNotes({
      [field]: existing ? `${existing}\n\n${template}` : template,
    });
  };

  const handleAddCitation = (e: FormEvent) => {
    e.preventDefault();
    const cleanUrl = newCitationUrl.trim();
    if (!cleanUrl) {
      setCitationError('Enter a Source URL to log a citation.');
      return;
    }

    const normalizedUrl =
      /^https?:\/\//i.test(cleanUrl) ? cleanUrl : `https://${cleanUrl}`;

    const entry: SourceCitation = {
      id: `src_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      title: newCitationTitle.trim(),
      url: normalizedUrl,
      dateAccessed: newCitationDate || todayIsoDate(),
      reliability: newCitationReliability,
    };

    onChangeNotes({ citations: [...citations, entry] });
    setNewCitationTitle('');
    setNewCitationUrl('');
    setNewCitationDate(todayIsoDate());
    setNewCitationReliability('Primary Regulatory');
    setCitationError(null);
  };

  const handleUpdateCitationReliability = (
    id: string,
    reliability: SourceReliability
  ) => {
    onChangeNotes({
      citations: citations.map((c) => (c.id === id ? { ...c, reliability } : c)),
    });
  };

  const handleDeleteCitation = (id: string) => {
    onChangeNotes({
      citations: citations.filter((c) => c.id !== id),
    });
  };

  const handleExportDocx = async () => {
    if (isExporting) return;
    setIsExporting(true);
    setExportStatus('idle');
    try {
      await exportInvestigationMemoDocx({
        subject,
        investigationType,
        notes,
        osintItems,
        reviewedIds,
      });
      setExportStatus('done');
      setTimeout(() => setExportStatus('idle'), 3000);
    } catch {
      setExportStatus('error');
    } finally {
      setIsExporting(false);
    }
  };

  const primaryCount = citations.filter(
    (c) => c.reliability === 'Primary Regulatory'
  ).length;
  const mediaCount = citations.filter(
    (c) => c.reliability === 'Reputable Media'
  ).length;
  const unverifiedCount = citations.filter(
    (c) => c.reliability === 'Unverified'
  ).length;

  return (
    <section
      id="analyst-notes-panel"
      aria-labelledby="analyst-notes-heading"
      className="bg-[#111826] border border-slate-800/90 rounded-xl flex flex-col"
    >
      {/* Panel Header */}
      <div className="px-6 py-5 border-b border-slate-800/80 flex flex-wrap items-start justify-between gap-4">
        <div>
          <h2
            id="analyst-notes-heading"
            className="text-lg font-semibold text-slate-100 tracking-tight"
          >
            IDD Analyst Notes
          </h2>
          <p className="mt-1 text-sm text-slate-400">
            Score risk dimensions, record findings, and track verified citations for the final memo.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          {lastSavedAt && (
            <span className="text-xs font-mono tabular-nums text-slate-500">
              Saved {lastSavedAt}
            </span>
          )}
        </div>
      </div>

      {/* Case Metadata & Risk Scoring Matrix */}
      <div className="px-6 py-4 border-b border-slate-800/70 bg-[#0D131F] space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label
              htmlFor="case-reference"
              className="block text-xs font-medium text-slate-400 mb-1.5"
            >
              Case Reference
            </label>
            <input
              id="case-reference"
              type="text"
              value={notes.caseReference}
              onChange={(e) => onChangeNotes({ caseReference: e.target.value })}
              placeholder="e.g., IDD-IND-2026-014"
              className="w-full bg-[#090D16] border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-blue-500/80 focus:ring-2 focus:ring-blue-500/20"
            />
          </div>

          <div>
            <label
              htmlFor="analyst-name"
              className="block text-xs font-medium text-slate-400 mb-1.5"
            >
              Lead Analyst
            </label>
            <input
              id="analyst-name"
              type="text"
              value={notes.analystName}
              onChange={(e) => onChangeNotes({ analystName: e.target.value })}
              placeholder="e.g., Ananya Verma, CFE"
              className="w-full bg-[#090D16] border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-blue-500/80 focus:ring-2 focus:ring-blue-500/20"
            />
          </div>
        </div>

        {/* Analyst Risk Scoring Matrix */}
        <div className="pt-4 border-t border-slate-800/70">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
            <span className="text-xs font-medium text-slate-300">
              IDD Risk Scoring Matrix (0 = Clear · 3 = Material Red Flag)
            </span>
            <span className="text-xs font-mono tabular-nums text-slate-300">
              Composite Score: {compositeScore} / 12
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {RISK_DIMENSIONS.map((dim) => {
              const current = riskScores[dim.key];
              return (
                <div
                  key={dim.key}
                  className="flex items-center justify-between gap-2 bg-[#090D16] border border-slate-800/80 rounded-lg px-3 py-2"
                >
                  <span className="text-xs text-slate-300 truncate">
                    {dim.label}
                  </span>
                  <div
                    role="radiogroup"
                    aria-label={dim.label}
                    className="flex items-center gap-1 shrink-0"
                  >
                    {SCORE_LEVELS.map((lvl) => {
                      const active = current === lvl.value;
                      const activeTone =
                        lvl.value === 0
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50'
                          : lvl.value === 1
                            ? 'bg-sky-500/20 text-sky-300 border-sky-500/50'
                            : lvl.value === 2
                              ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                              : 'bg-rose-500/20 text-rose-300 border-rose-500/50';
                      return (
                        <button
                          key={lvl.value}
                          type="button"
                          role="radio"
                          aria-checked={active}
                          onClick={() => handleScoreChange(dim.key, lvl.value)}
                          className={`w-6 h-6 text-[11px] font-mono tabular-nums rounded border transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                            active
                              ? activeTone
                              : 'bg-transparent border-slate-800 text-slate-500 hover:text-slate-300 hover:border-slate-700'
                          }`}
                        >
                          {lvl.label}
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Final Risk Rating Override */}
        <div>
          <span className="block text-xs font-medium text-slate-400 mb-1.5">
            Preliminary Risk Assessment
          </span>
          <div
            role="radiogroup"
            aria-label="Preliminary Risk Assessment"
            className="grid grid-cols-2 sm:grid-cols-4 gap-2"
          >
            {RISK_OPTIONS.map((option) => {
              const selected = notes.riskRating === option.value;
              return (
                <button
                  key={option.value}
                  type="button"
                  role="radio"
                  aria-checked={selected}
                  onClick={() => onChangeNotes({ riskRating: option.value })}
                  className={`px-3 py-2 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                    selected
                      ? option.activeClass
                      : 'bg-[#090D16] border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                  }`}
                >
                  {option.label}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Three Structured Note Sections + Source Verification Table */}
      <div className="divide-y divide-slate-800/80 flex-1">
        {/* Section 1: Corporate Background */}
        <div className="px-6 py-5">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-2.5">
            <label
              htmlFor="notes-corporate-background"
              className="text-sm font-semibold text-slate-100"
            >
              01. Corporate Background
            </label>
            <div className="flex items-center gap-3">
              <span className="text-xs font-mono tabular-nums text-slate-500">
                {countWords(notes.corporateBackground)} words
              </span>
              <button
                type="button"
                onClick={() => handleInsertPrompt('corporateBackground')}
                className="inline-flex items-center gap-1 text-xs font-medium text-blue-400 hover:text-blue-300 transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded px-1.5 py-0.5"
              >
                <ListPlus className="w-3.5 h-3.5" aria-hidden="true" />
                Insert prompts
              </button>
            </div>
          </div>
          <textarea
            id="notes-corporate-background"
            rows={4}
            value={notes.corporateBackground}
            onChange={(e) => onChangeNotes({ corporateBackground: e.target.value })}
            placeholder="Document MCA21 incorporation details, active/struck-off status, DIN linkages, beneficial ownership, paid-up capital, and related-party entities..."
            className="w-full bg-[#090D16] border border-slate-800 rounded-lg px-3.5 py-2.5 text-sm text-slate-200 placeholder:text-slate-600 leading-relaxed focus:outline-none focus:border-blue-500/80 focus:ring-2 focus:ring-blue-500/20 resize-y"
          />
        </div>

        {/* Section 2: Regulatory & Litigation Red Flags */}
        <div className="px-6 py-5">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-2.5">
            <label
              htmlFor="notes-regulatory-red-flags"
              className="text-sm font-semibold text-slate-100"
            >
              02. Regulatory & Litigation Red Flags
            </label>
            <div className="flex items-center gap-3">
              <span className="text-xs font-mono tabular-nums text-slate-500">
                {countWords(notes.regulatoryLitigationRedFlags)} words
              </span>
              <button
                type="button"
                onClick={() => handleInsertPrompt('regulatoryLitigationRedFlags')}
                className="inline-flex items-center gap-1 text-xs font-medium text-blue-400 hover:text-blue-300 transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded px-1.5 py-0.5"
              >
                <ListPlus className="w-3.5 h-3.5" aria-hidden="true" />
                Insert prompts
              </button>
            </div>
          </div>
          <textarea
            id="notes-regulatory-red-flags"
            rows={4}
            value={notes.regulatoryLitigationRedFlags}
            onChange={(e) =>
              onChangeNotes({ regulatoryLitigationRedFlags: e.target.value })
            }
            placeholder="Summarize SEBI enforcement orders, NCLT/IBBI insolvency filings, High Court / e-Courts / Sec 138 NI Act dockets, RBI wilful defaulter listings, or ROC disqualifications..."
            className="w-full bg-[#090D16] border border-slate-800 rounded-lg px-3.5 py-2.5 text-sm text-slate-200 placeholder:text-slate-600 leading-relaxed focus:outline-none focus:border-blue-500/80 focus:ring-2 focus:ring-blue-500/20 resize-y"
          />
        </div>

        {/* Section 3: Adverse Media Findings */}
        <div className="px-6 py-5">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-2.5">
            <label
              htmlFor="notes-adverse-media"
              className="text-sm font-semibold text-slate-100"
            >
              03. Adverse Media Findings
            </label>
            <div className="flex items-center gap-3">
              <span className="text-xs font-mono tabular-nums text-slate-500">
                {countWords(notes.adverseMediaFindings)} words
              </span>
              <button
                type="button"
                onClick={() => handleInsertPrompt('adverseMediaFindings')}
                className="inline-flex items-center gap-1 text-xs font-medium text-blue-400 hover:text-blue-300 transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded px-1.5 py-0.5"
              >
                <ListPlus className="w-3.5 h-3.5" aria-hidden="true" />
                Insert prompts
              </button>
            </div>
          </div>
          <textarea
            id="notes-adverse-media"
            rows={4}
            value={notes.adverseMediaFindings}
            onChange={(e) => onChangeNotes({ adverseMediaFindings: e.target.value })}
            placeholder="Log ED (PMLA/FEMA) raids, CBI/SFIO/EOW investigations, investigative press reports, PEP nexus, or sanctions hits with publication dates and source URLs..."
            className="w-full bg-[#090D16] border border-slate-800 rounded-lg px-3.5 py-2.5 text-sm text-slate-200 placeholder:text-slate-600 leading-relaxed focus:outline-none focus:border-blue-500/80 focus:ring-2 focus:ring-blue-500/20 resize-y"
          />
        </div>

        {/* Section 4: Upgrade 3 — Source Verification Table (Kroll / A&M standard) */}
        <div className="px-6 py-5 space-y-4">
          <div className="flex flex-wrap items-baseline justify-between gap-2">
            <div>
              <h3 className="text-sm font-semibold text-slate-100">
                04. Source Verification Table
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Log primary orders, court dockets, and press citations with reliability ratings for memo auditability.
              </p>
            </div>
            <div className="text-xs font-mono tabular-nums text-slate-400">
              <span>{citations.length} logged</span>
              <span className="mx-1.5 text-slate-600" aria-hidden="true">·</span>
              <span className="text-emerald-400">{primaryCount} Primary</span>
              <span className="mx-1.5 text-slate-600" aria-hidden="true">·</span>
              <span className="text-sky-400">{mediaCount} Media</span>
              <span className="mx-1.5 text-slate-600" aria-hidden="true">·</span>
              <span className="text-amber-400">{unverifiedCount} Unverified</span>
            </div>
          </div>

          {/* Add Citation Form */}
          <form
            onSubmit={handleAddCitation}
            noValidate
            className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-end bg-[#0D131F] border border-slate-800/80 rounded-lg p-3"
          >
            <div className="sm:col-span-4">
              <label
                htmlFor="citation-title"
                className="block text-[11px] font-medium text-slate-400 mb-1"
              >
                Citation / Finding Label (Optional)
              </label>
              <input
                id="citation-title"
                type="text"
                value={newCitationTitle}
                onChange={(e) => setNewCitationTitle(e.target.value)}
                placeholder="e.g., SEBI WTM Order 2024"
                className="w-full bg-[#090D16] border border-slate-800 rounded-md px-2.5 py-1.5 text-xs text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-blue-500/80"
              />
            </div>

            <div className="sm:col-span-4">
              <label
                htmlFor="citation-url"
                className="block text-[11px] font-medium text-slate-400 mb-1"
              >
                Source URL
              </label>
              <input
                id="citation-url"
                type="url"
                value={newCitationUrl}
                onChange={(e) => {
                  setNewCitationUrl(e.target.value);
                  if (citationError) setCitationError(null);
                }}
                placeholder="https://sebi.gov.in/..."
                className="w-full bg-[#090D16] border border-slate-800 rounded-md px-2.5 py-1.5 text-xs font-mono text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-blue-500/80"
              />
            </div>

            <div className="sm:col-span-2">
              <label
                htmlFor="citation-date"
                className="block text-[11px] font-medium text-slate-400 mb-1"
              >
                Date Accessed
              </label>
              <input
                id="citation-date"
                type="date"
                value={newCitationDate}
                onChange={(e) => setNewCitationDate(e.target.value)}
                className="w-full bg-[#090D16] border border-slate-800 rounded-md px-2 py-1.5 text-xs font-mono text-slate-200 focus:outline-none focus:border-blue-500/80"
              />
            </div>

            <div className="sm:col-span-2">
              <label
                htmlFor="citation-reliability"
                className="block text-[11px] font-medium text-slate-400 mb-1"
              >
                Reliability Rating
              </label>
              <select
                id="citation-reliability"
                value={newCitationReliability}
                onChange={(e) =>
                  setNewCitationReliability(e.target.value as SourceReliability)
                }
                className="w-full bg-[#090D16] border border-slate-800 rounded-md px-2 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500/80"
              >
                {RELIABILITY_OPTIONS.map((opt) => (
                  <option key={opt} value={opt}>
                    {opt}
                  </option>
                ))}
              </select>
            </div>

            <div className="sm:col-span-12 flex items-center justify-between gap-2 pt-1">
              <div>
                {citationError && (
                  <span role="alert" className="text-xs text-rose-400">
                    {citationError}
                  </span>
                )}
              </div>
              <button
                type="submit"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-100 bg-[#182235] border border-slate-700 hover:border-slate-500 rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
              >
                <Plus className="w-3.5 h-3.5 text-blue-400" aria-hidden="true" />
                Add Source Citation
              </button>
            </div>
          </form>

          {/* Citation Table */}
          <div className="border border-slate-800/80 rounded-lg overflow-x-auto">
            <table className="w-full text-left border-collapse min-w-[560px]">
              <thead>
                <tr className="bg-[#0D131F] border-b border-slate-800/80 text-[11px] font-semibold text-slate-400">
                  <th className="py-2.5 px-3 w-10">#</th>
                  <th className="py-2.5 px-3">Source URL</th>
                  <th className="py-2.5 px-3 w-28">Date Accessed</th>
                  <th className="py-2.5 px-3 w-40">Reliability Rating</th>
                  <th className="py-2.5 px-3 w-16 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/70 text-xs">
                {citations.length === 0 ? (
                  <tr>
                    <td
                      colSpan={5}
                      className="py-6 px-4 text-center text-slate-500"
                    >
                      No citations added yet. Add a regulatory order, court docket, or media URL above.
                    </td>
                  </tr>
                ) : (
                  citations.map((item, index) => (
                    <tr
                      key={item.id}
                      className="hover:bg-[#141D2E]/50 transition-colors"
                    >
                      <td className="py-2.5 px-3 font-mono tabular-nums text-slate-500 align-top">
                        {String(index + 1).padStart(2, '0')}
                      </td>
                      <td className="py-2.5 px-3 align-top max-w-[260px]">
                        {item.title && (
                          <div className="font-medium text-slate-200 mb-0.5 truncate">
                            {item.title}
                          </div>
                        )}
                        <a
                          href={item.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 font-mono text-[11px] text-blue-400 hover:text-blue-300 break-all"
                        >
                          <span className="truncate max-w-[220px]">{item.url}</span>
                          <ExternalLink className="w-3 h-3 shrink-0" aria-hidden="true" />
                        </a>
                      </td>
                      <td className="py-2.5 px-3 font-mono tabular-nums text-slate-300 align-top whitespace-nowrap">
                        {item.dateAccessed}
                      </td>
                      <td className="py-2.5 px-3 align-top">
                        <select
                          aria-label={`Reliability rating for ${item.title || item.url}`}
                          value={item.reliability}
                          onChange={(e) =>
                            handleUpdateCitationReliability(
                              item.id,
                              e.target.value as SourceReliability
                            )
                          }
                          className={`bg-[#090D16] border border-slate-800 rounded px-2 py-1 text-xs font-medium focus:outline-none focus:border-blue-500/80 ${reliabilityTextClass(
                            item.reliability
                          )}`}
                        >
                          {RELIABILITY_OPTIONS.map((opt) => (
                            <option key={opt} value={opt} className="text-slate-200">
                              {opt}
                            </option>
                          ))}
                        </select>
                      </td>
                      <td className="py-2.5 px-3 text-right align-top">
                        <button
                          type="button"
                          onClick={() => handleDeleteCitation(item.id)}
                          aria-label={`Remove source ${item.title || item.url}`}
                          className="p-1 text-slate-500 hover:text-rose-400 transition-colors rounded cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Export Footer */}
      <div className="px-6 py-4 border-t border-slate-800/80 bg-[#0D131F] rounded-b-xl flex flex-wrap items-center justify-between gap-4">
        <div className="text-xs text-slate-400 font-mono tabular-nums">
          <span>{totalWords} words</span>
          <span className="mx-2 text-slate-600" aria-hidden="true">·</span>
          <span>Risk {compositeScore}/12</span>
          <span className="mx-2 text-slate-600" aria-hidden="true">·</span>
          <span>{citations.length} citations</span>
          <span className="mx-2 text-slate-600" aria-hidden="true">·</span>
          <span>
            {reviewedIds.length}/{osintItems.length} checks
          </span>
        </div>

        <div className="flex items-center gap-3">
          {exportStatus === 'done' && (
            <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-400">
              <Check className="w-4 h-4" aria-hidden="true" />
              Memo downloaded
            </span>
          )}
          {exportStatus === 'error' && (
            <span className="text-xs font-medium text-rose-400">
              Export failed. Please try again.
            </span>
          )}

          <button
            type="button"
            onClick={handleExportDocx}
            disabled={isExporting}
            className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium text-white bg-blue-600 hover:bg-blue-500 disabled:opacity-60 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
          >
            <FileDown className="w-4 h-4" aria-hidden="true" />
            {isExporting ? 'Generating Memo...' : 'Export to Word (.docx)'}
          </button>
        </div>
      </div>
    </section>
  );
}
