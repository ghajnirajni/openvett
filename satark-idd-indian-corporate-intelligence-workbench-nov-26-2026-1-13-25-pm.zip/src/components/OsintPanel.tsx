import { useMemo, useState } from 'react';
import {
  Check,
  Copy,
  ExternalLink,
  RotateCcw,
  Search,
} from 'lucide-react';
import {
  InvestigationType,
  OsintCategoryId,
  OsintQueryItem,
} from '../types/investigation';
import {
  getInvestigationTypeMeta,
  INVESTIGATION_TYPES,
  OSINT_CATEGORIES,
} from '../utils/osintBuilder';

interface OsintPanelProps {
  items: OsintQueryItem[];
  investigationType: InvestigationType;
  onChangeInvestigationType: (type: InvestigationType) => void;
  reviewedIds: string[];
  onToggleReviewed: (id: string) => void;
  onMarkReviewed: (id: string) => void;
  onResetReviewed: () => void;
}

export function OsintPanel({
  items,
  investigationType,
  onChangeInvestigationType,
  reviewedIds,
  onToggleReviewed,
  onMarkReviewed,
  onResetReviewed,
}: OsintPanelProps) {
  const [activeCategory, setActiveCategory] = useState<'all' | OsintCategoryId>('all');
  const [searchFilter, setSearchFilter] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const activeTypeMeta = getInvestigationTypeMeta(investigationType);

  const filteredItems = useMemo(() => {
    const q = searchFilter.trim().toLowerCase();
    return items.filter((item) => {
      const matchesCat = activeCategory === 'all' || item.category === activeCategory;
      if (!matchesCat) return false;
      if (!q) return true;
      return (
        item.title.toLowerCase().includes(q) ||
        item.categoryLabel.toLowerCase().includes(q) ||
        item.registrySource.toLowerCase().includes(q) ||
        item.query.toLowerCase().includes(q)
      );
    });
  }, [items, activeCategory, searchFilter]);

  const handleCopyQuery = async (id: string, query: string) => {
    try {
      await navigator.clipboard.writeText(query);
      setCopiedId(id);
      setTimeout(() => {
        setCopiedId((prev) => (prev === id ? null : prev));
      }, 1800);
    } catch {
      // Clipboard blocked in restricted frames
    }
  };

  return (
    <section
      id="osint-panel"
      aria-labelledby="osint-panel-heading"
      className="bg-[#111826] border border-slate-800/90 rounded-xl flex flex-col"
    >
      {/* Panel Header */}
      <div className="px-6 py-5 border-b border-slate-800/80 flex flex-wrap items-start justify-between gap-4">
        <div>
          <h2
            id="osint-panel-heading"
            className="text-lg font-semibold text-slate-100 tracking-tight"
          >
            Targeted OSINT & Regulatory Search Links
          </h2>
          <p className="mt-1 text-sm text-slate-400">
            Boolean Google queries tailored dynamically to your selected investigation mandate.
          </p>
        </div>

        <div className="flex items-center gap-4 shrink-0">
          <span className="text-xs font-mono tabular-nums text-slate-400">
            {reviewedIds.length} / {items.length} reviewed
          </span>
          {reviewedIds.length > 0 && (
            <button
              type="button"
              onClick={onResetReviewed}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-400 hover:text-slate-200 transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded px-1.5 py-1"
            >
              <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
              Reset checks
            </button>
          )}
        </div>
      </div>

      {/* Upgrade 1: Investigation Type Dynamic Keyword Matrix */}
      <div className="px-6 py-4 border-b border-slate-800/80 bg-[#0C121E]">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-2.5">
          <span className="text-xs font-medium text-slate-300">
            Investigation Type · Red-Flag Keyword Matrix
          </span>
          <span className="text-xs font-mono text-blue-400">
            Active: {activeTypeMeta.shortLabel}
          </span>
        </div>

        <div
          role="radiogroup"
          aria-label="Investigation Type"
          className="grid grid-cols-1 sm:grid-cols-3 gap-2"
        >
          {INVESTIGATION_TYPES.map((typeOption) => {
            const isSelected = typeOption.id === investigationType;
            return (
              <button
                key={typeOption.id}
                type="button"
                role="radio"
                aria-checked={isSelected}
                onClick={() => onChangeInvestigationType(typeOption.id)}
                className={`px-3 py-2 text-xs font-medium rounded-lg border text-left transition-colors whitespace-nowrap truncate cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                  isSelected
                    ? 'bg-blue-600/15 border-blue-500/60 text-blue-200'
                    : 'bg-[#090D16] border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                }`}
              >
                {typeOption.label}
              </button>
            );
          })}
        </div>

        <p className="mt-2.5 text-xs text-slate-400 leading-relaxed">
          {activeTypeMeta.focusSummary}
        </p>
      </div>

      {/* Category Filter Toolbar */}
      <div className="px-6 py-3.5 border-b border-slate-800/70 bg-[#0D131F] flex flex-col gap-3">
        <div
          role="tablist"
          aria-label="Filter OSINT links by Indian regulatory category"
          className="flex items-center gap-1.5 overflow-x-auto pb-1"
        >
          <button
            type="button"
            role="tab"
            aria-selected={activeCategory === 'all'}
            onClick={() => setActiveCategory('all')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
              activeCategory === 'all'
                ? 'bg-blue-600 text-white'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/70'
            }`}
          >
            All ({items.length})
          </button>
          {OSINT_CATEGORIES.map((cat) => {
            const count = items.filter((i) => i.category === cat.id).length;
            const isActive = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                role="tab"
                aria-selected={isActive}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                  isActive
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/70'
                }`}
              >
                {cat.shortLabel} ({count})
              </button>
            );
          })}
        </div>

        <div className="relative">
          <Search
            className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
            aria-hidden="true"
          />
          <input
            type="text"
            value={searchFilter}
            onChange={(e) => setSearchFilter(e.target.value)}
            placeholder="Filter queries by registry, keyword, or operator..."
            aria-label="Filter OSINT queries"
            className="w-full bg-[#090D16] border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-blue-500/80 focus:ring-2 focus:ring-blue-500/20"
          />
        </div>
      </div>

      {/* Query List */}
      <div className="divide-y divide-slate-800/80">
        {filteredItems.length === 0 ? (
          <div className="px-6 py-12 text-center">
            <p className="text-sm text-slate-400">
              No OSINT queries match &ldquo;{searchFilter}&rdquo;.
            </p>
            <button
              type="button"
              onClick={() => {
                setSearchFilter('');
                setActiveCategory('all');
              }}
              className="mt-3 text-xs font-medium text-blue-400 hover:text-blue-300 transition-colors cursor-pointer"
            >
              Show all {items.length} queries
            </button>
          </div>
        ) : (
          filteredItems.map((item) => {
            const isReviewed = reviewedIds.includes(item.id);
            const isCopied = copiedId === item.id;

            return (
              <div
                key={item.id}
                className={`px-6 py-4 transition-colors ${
                  isReviewed ? 'bg-[#0E1523]/70' : 'hover:bg-[#141D2E]/50'
                }`}
              >
                <div className="flex items-start gap-3.5">
                  <div className="pt-0.5 shrink-0">
                    <input
                      id={`check-${item.id}`}
                      type="checkbox"
                      checked={isReviewed}
                      onChange={() => onToggleReviewed(item.id)}
                      aria-label={`Mark ${item.title} as reviewed`}
                      className="h-4 w-4 rounded border-slate-600 bg-[#090D16] text-blue-600 focus:ring-blue-500 focus:ring-offset-[#111826] cursor-pointer"
                    />
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-slate-400">
                      <span className="font-medium text-slate-300">
                        {item.categoryLabel}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono text-[11px] text-slate-400">
                        {item.registrySource}
                      </span>
                      {isReviewed && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="text-emerald-400 font-medium">
                            Reviewed
                          </span>
                        </>
                      )}
                    </div>

                    <div className="mt-1 flex flex-wrap items-center justify-between gap-3">
                      <label
                        htmlFor={`check-${item.id}`}
                        className={`text-sm font-semibold cursor-pointer ${
                          isReviewed ? 'text-slate-300' : 'text-slate-100'
                        }`}
                      >
                        {item.title}
                      </label>

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleCopyQuery(item.id, item.query)}
                          className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-300 bg-[#090D16] border border-slate-700/80 rounded-md hover:border-slate-600 hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
                        >
                          {isCopied ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-400" aria-hidden="true" />
                              Copied
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5 text-slate-400" aria-hidden="true" />
                              Copy Query
                            </>
                          )}
                        </button>

                        <a
                          href={item.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={() => onMarkReviewed(item.id)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-blue-600 hover:bg-blue-500 rounded-md transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
                        >
                          Search Google
                          <ExternalLink className="w-3.5 h-3.5" aria-hidden="true" />
                        </a>
                      </div>
                    </div>

                    <p className="mt-1 text-xs text-slate-400 leading-relaxed">
                      {item.rationale}
                    </p>

                    <div className="mt-2.5 bg-[#090D16] border border-slate-800/80 rounded-md px-3 py-2 font-mono text-[11px] text-slate-300/90 leading-relaxed break-all select-all">
                      {item.query}
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </section>
  );
}
