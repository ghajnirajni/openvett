import {
  ChangeEvent,
  FormEvent,
  PointerEvent,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import {
  FileSpreadsheet,
  GitBranch,
  Maximize2,
  Plus,
  RefreshCw,
  Trash2,
  Upload,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import {
  EntityDirectorLink,
  InvestigationSubject,
} from '../types/investigation';

interface RelationshipMapperPanelProps {
  subject: InvestigationSubject;
  entityLinks: EntityDirectorLink[];
  onUpdateEntityLinks: (links: EntityDirectorLink[]) => void;
  onAppendFindingsToMemo: (summaryText: string) => void;
}

type NodeKind = 'company' | 'director' | 'address';

interface GraphNode {
  id: string;
  kind: NodeKind;
  label: string;
  sublabel?: string;
  isFlagged: boolean;
  flagReason?: string;
  connectedIds: string[];
  x: number;
  y: number;
}

interface GraphEdge {
  id: string;
  source: string;
  target: string;
  kind: 'directorship' | 'shared_address';
  isFlagged: boolean;
}

type GraphFilterMode = 'all' | 'shared_directors' | 'shared_addresses';

const SAMPLE_MCA21_CSV = `Company Name,Director Name,DIN,Registered Address
ABC Infra Pvt Ltd,Ramesh Sharma,01234567,"402 Peninsula Corporate Park, Lower Parel, Mumbai 400013"
ABC Infra Pvt Ltd,Vikram Mehta,02948112,"402 Peninsula Corporate Park, Lower Parel, Mumbai 400013"
Horizon Buildcon LLP,Ramesh Sharma,01234567,"402 Peninsula Corporate Park, Lower Parel, Mumbai 400013"
Horizon Buildcon LLP,Neha Kulkarni,07812450,"402 Peninsula Corporate Park, Lower Parel, Mumbai 400013"
Deccan Logistics Ventures Pvt Ltd,Ramesh Sharma,01234567,"18 MG Road, Indiranagar, Bengaluru 560008"
Deccan Logistics Ventures Pvt Ltd,Suresh Iyer,05129044,"18 MG Road, Indiranagar, Bengaluru 560008"
Apex Realty Holdings Pvt Ltd,Vikram Mehta,02948112,"Suite 12, Nariman Bhavan, Nariman Point, Mumbai 400021"`;

function normalizeKey(value: string): string {
  return value
    .toLowerCase()
    .replace(/[.,/#!$%^&*;:{}=\-_`~()]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function splitCsvLine(line: string, delimiter: ',' | '\t'): string[] {
  if (delimiter === '\t') {
    return line.split('\t').map((cell) => cell.trim().replace(/^"|"$/g, ''));
  }
  const result: string[] = [];
  let current = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (ch === ',' && !inQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += ch;
    }
  }
  result.push(current.trim());
  return result;
}

function parseMcaCsvText(rawText: string): EntityDirectorLink[] {
  const lines = rawText
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);

  if (lines.length === 0) return [];

  const delimiter: ',' | '\t' = lines[0].includes('\t') ? '\t' : ',';
  const rows = lines.map((line) => splitCsvLine(line, delimiter));

  // Detect optional header row
  let startIndex = 0;
  let colMap = { company: 0, director: 1, din: 2, address: 3 };

  const headerCandidate = rows[0].map((c) => c.toLowerCase());
  const looksLikeHeader = headerCandidate.some(
    (h) =>
      h.includes('company') ||
      h.includes('entity') ||
      h.includes('director') ||
      h.includes('din') ||
      h.includes('address')
  );

  if (looksLikeHeader) {
    startIndex = 1;
    const findCol = (patterns: string[], fallback: number) => {
      const idx = headerCandidate.findIndex((h) =>
        patterns.some((p) => h.includes(p))
      );
      return idx >= 0 ? idx : fallback;
    };
    colMap = {
      company: findCol(['company', 'entity', 'name of company'], 0),
      director: findCol(['director', 'signatory', 'promoter', 'partner'], 1),
      din: findCol(['din', 'dpin', 'pan'], 2),
      address: findCol(['address', 'registered', 'office'], 3),
    };
  }

  const parsed: EntityDirectorLink[] = [];
  for (let i = startIndex; i < rows.length; i++) {
    const row = rows[i];
    const companyName = (row[colMap.company] ?? '').trim();
    const directorName = (row[colMap.director] ?? '').trim();
    const din = (row[colMap.din] ?? '').trim().toUpperCase();
    const registeredAddress = (row[colMap.address] ?? '').trim();

    if (!companyName && !directorName) continue;

    parsed.push({
      id: `link_${Date.now()}_${i}_${Math.random().toString(36).slice(2, 6)}`,
      companyName: companyName || 'Unnamed Entity',
      directorName: directorName || 'Unnamed Director',
      din,
      registeredAddress,
    });
  }
  return parsed;
}

function buildGraphAnalysis(links: EntityDirectorLink[]) {
  const companyMap = new Map<
    string,
    { label: string; addressSet: Set<string>; directorKeys: Set<string> }
  >();
  const directorMap = new Map<
    string,
    { label: string; din: string; companyKeys: Set<string> }
  >();
  const addressMap = new Map<
    string,
    { label: string; companyKeys: Set<string> }
  >();

  for (const row of links) {
    const compKey = normalizeKey(row.companyName);
    if (!compKey) continue;

    if (!companyMap.has(compKey)) {
      companyMap.set(compKey, {
        label: row.companyName.trim(),
        addressSet: new Set(),
        directorKeys: new Set(),
      });
    }
    const compEntry = companyMap.get(compKey)!;

    const dirKey = row.din.trim()
      ? `din:${row.din.trim().toUpperCase()}`
      : `name:${normalizeKey(row.directorName)}`;

    if (row.directorName.trim()) {
      if (!directorMap.has(dirKey)) {
        directorMap.set(dirKey, {
          label: row.directorName.trim(),
          din: row.din.trim().toUpperCase(),
          companyKeys: new Set(),
        });
      }
      const dirEntry = directorMap.get(dirKey)!;
      if (!dirEntry.din && row.din.trim()) {
        dirEntry.din = row.din.trim().toUpperCase();
      }
      dirEntry.companyKeys.add(compKey);
      compEntry.directorKeys.add(dirKey);
    }

    const addrKey = normalizeKey(row.registeredAddress);
    if (addrKey) {
      compEntry.addressSet.add(row.registeredAddress.trim());
      if (!addressMap.has(addrKey)) {
        addressMap.set(addrKey, {
          label: row.registeredAddress.trim(),
          companyKeys: new Set(),
        });
      }
      addressMap.get(addrKey)!.companyKeys.add(compKey);
    }
  }

  const sharedDirectors = Array.from(directorMap.entries())
    .filter(([, d]) => d.companyKeys.size >= 2)
    .map(([key, d]) => ({
      key,
      name: d.label,
      din: d.din,
      companies: Array.from(d.companyKeys).map(
        (ck) => companyMap.get(ck)?.label ?? ck
      ),
    }));

  const sharedAddresses = Array.from(addressMap.entries())
    .filter(([, a]) => a.companyKeys.size >= 2)
    .map(([key, a]) => ({
      key,
      address: a.label,
      companies: Array.from(a.companyKeys).map(
        (ck) => companyMap.get(ck)?.label ?? ck
      ),
    }));

  const nodes: GraphNode[] = [];
  const edges: GraphEdge[] = [];

  const companyEntries = Array.from(companyMap.entries());
  const directorEntries = Array.from(directorMap.entries());
  const sharedAddressEntries = Array.from(addressMap.entries()).filter(
    ([, a]) => a.companyKeys.size >= 2
  );

  const width = 920;
  const height = 520;

  // Deterministic initial layout: companies in center-top band, directors in lower band, shared addresses in upper arc
  companyEntries.forEach(([compKey, comp], idx) => {
    const cols = Math.max(1, companyEntries.length);
    const x = ((idx + 1) / (cols + 1)) * (width - 140) + 70;
    const y = sharedAddressEntries.length > 0 ? 255 : 195;

    const coLocated = sharedAddressEntries.some(([, a]) =>
      a.companyKeys.has(compKey)
    );
    const addrList = Array.from(comp.addressSet);

    nodes.push({
      id: `c:${compKey}`,
      kind: 'company',
      label: comp.label,
      sublabel: addrList[0] || undefined,
      isFlagged: coLocated,
      flagReason: coLocated ? 'Shares registered office address' : undefined,
      connectedIds: [],
      x,
      y,
    });
  });

  directorEntries.forEach(([dirKey, dir], idx) => {
    const cols = Math.max(1, directorEntries.length);
    const x = ((idx + 1) / (cols + 1)) * (width - 120) + 60;
    const y = 420 + (idx % 2 === 0 ? -18 : 18);
    const isShared = dir.companyKeys.size >= 2;

    nodes.push({
      id: `d:${dirKey}`,
      kind: 'director',
      label: dir.label,
      sublabel: dir.din ? `DIN ${dir.din}` : undefined,
      isFlagged: isShared,
      flagReason: isShared
        ? `Shared director across ${dir.companyKeys.size} entities`
        : undefined,
      connectedIds: [],
      x,
      y,
    });

    dir.companyKeys.forEach((compKey) => {
      edges.push({
        id: `e:d:${dirKey}->c:${compKey}`,
        source: `d:${dirKey}`,
        target: `c:${compKey}`,
        kind: 'directorship',
        isFlagged: isShared,
      });
    });
  });

  sharedAddressEntries.forEach(([addrKey, addr], idx) => {
    const cols = Math.max(1, sharedAddressEntries.length);
    const x = ((idx + 1) / (cols + 1)) * (width - 200) + 100;
    const y = 92;

    nodes.push({
      id: `a:${addrKey}`,
      kind: 'address',
      label: addr.label,
      sublabel: `${addr.companyKeys.size} co-located entities`,
      isFlagged: true,
      flagReason: `Common registered address shared by ${addr.companyKeys.size} companies`,
      connectedIds: [],
      x,
      y,
    });

    addr.companyKeys.forEach((compKey) => {
      edges.push({
        id: `e:a:${addrKey}->c:${compKey}`,
        source: `a:${addrKey}`,
        target: `c:${compKey}`,
        kind: 'shared_address',
        isFlagged: true,
      });
    });
  });

  // Populate adjacency for inspector
  const nodeById = new Map(nodes.map((n) => [n.id, n]));
  for (const edge of edges) {
    nodeById.get(edge.source)?.connectedIds.push(edge.target);
    nodeById.get(edge.target)?.connectedIds.push(edge.source);
  }

  // Gentle spring relaxation to avoid overlap
  const iterations = 45;
  for (let iter = 0; iter < iterations; iter++) {
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const a = nodes[i];
        const b = nodes[j];
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const dist = Math.hypot(dx, dy) || 1;
        const minDist = a.kind === 'company' || b.kind === 'company' ? 135 : 105;
        if (dist < minDist) {
          const push = ((minDist - dist) / dist) * 0.35;
          a.x -= dx * push;
          a.y -= dy * push;
          b.x += dx * push;
          b.y += dy * push;
        }
      }
    }
    for (const edge of edges) {
      const s = nodeById.get(edge.source);
      const t = nodeById.get(edge.target);
      if (!s || !t) continue;
      const dx = t.x - s.x;
      const dy = t.y - s.y;
      const dist = Math.hypot(dx, dy) || 1;
      const ideal = edge.kind === 'shared_address' ? 150 : 165;
      const pull = ((dist - ideal) / dist) * 0.08;
      s.x += dx * pull;
      s.y += dy * pull;
      t.x -= dx * pull;
      t.y -= dy * pull;
    }
    for (const n of nodes) {
      n.x = Math.max(85, Math.min(width - 85, n.x));
      n.y = Math.max(55, Math.min(height - 55, n.y));
    }
  }

  return { nodes, edges, sharedDirectors, sharedAddresses };
}

function truncateLabel(text: string, maxLen: number): string {
  if (text.length <= maxLen) return text;
  return `${text.slice(0, maxLen - 1)}…`;
}

export function RelationshipMapperPanel({
  subject,
  entityLinks,
  onUpdateEntityLinks,
  onAppendFindingsToMemo,
}: RelationshipMapperPanelProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);

  const [csvText, setCsvText] = useState('');
  const [parseMessage, setParseMessage] = useState<string | null>(null);

  // Manual row entry
  const [manualCompany, setManualCompany] = useState(subject.companyName || '');
  const [manualDirector, setManualDirector] = useState(subject.subjectName || '');
  const [manualDin, setManualDin] = useState('');
  const [manualAddress, setManualAddress] = useState('');

  // Graph UI states
  const [filterMode, setFilterMode] = useState<GraphFilterMode>('all');
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [nodePositions, setNodePositions] = useState<
    Record<string, { x: number; y: number }>
  >({});
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [memoAppendedNotice, setMemoAppendedNotice] = useState(false);

  const dragStateRef = useRef<{
    mode: 'node' | 'pan' | null;
    nodeId?: string;
    startClientX: number;
    startClientY: number;
    origX: number;
    origY: number;
  }>({ mode: null, startClientX: 0, startClientY: 0, origX: 0, origY: 0 });

  const analysis = useMemo(
    () => buildGraphAnalysis(entityLinks),
    [entityLinks]
  );

  // Reset manual positions whenever dataset changes structurally
  useEffect(() => {
    const initial: Record<string, { x: number; y: number }> = {};
    for (const node of analysis.nodes) {
      initial[node.id] = { x: node.x, y: node.y };
    }
    setNodePositions(initial);
    setSelectedNodeId((prev) =>
      prev && analysis.nodes.some((n) => n.id === prev) ? prev : null
    );
  }, [analysis]);

  const visibleGraph = useMemo(() => {
    if (filterMode === 'all') {
      return { nodes: analysis.nodes, edges: analysis.edges };
    }
    if (filterMode === 'shared_directors') {
      const flaggedDirectorIds = new Set(
        analysis.nodes
          .filter((n) => n.kind === 'director' && n.isFlagged)
          .map((n) => n.id)
      );
      const edges = analysis.edges.filter((e) =>
        flaggedDirectorIds.has(e.source)
      );
      const keepIds = new Set<string>(flaggedDirectorIds);
      edges.forEach((e) => keepIds.add(e.target));
      return {
        nodes: analysis.nodes.filter((n) => keepIds.has(n.id)),
        edges,
      };
    }
    // shared_addresses
    const addressIds = new Set(
      analysis.nodes.filter((n) => n.kind === 'address').map((n) => n.id)
    );
    const edges = analysis.edges.filter((e) => addressIds.has(e.source));
    const keepIds = new Set<string>(addressIds);
    edges.forEach((e) => keepIds.add(e.target));
    return {
      nodes: analysis.nodes.filter((n) => keepIds.has(n.id)),
      edges,
    };
  }, [analysis, filterMode]);

  const selectedNode = useMemo(
    () => analysis.nodes.find((n) => n.id === selectedNodeId) ?? null,
    [analysis.nodes, selectedNodeId]
  );

  const handleLoadSampleCsv = () => {
    setCsvText(SAMPLE_MCA21_CSV);
    const parsed = parseMcaCsvText(SAMPLE_MCA21_CSV);
    onUpdateEntityLinks(parsed);
    setParseMessage(`Loaded ${parsed.length} sample MCA21 director-entity mappings.`);
    setFilterMode('all');
  };

  const handleParsePaste = () => {
    const parsed = parseMcaCsvText(csvText);
    if (parsed.length === 0) {
      setParseMessage(
        'No valid rows found. Format: Company Name, Director Name, DIN, Registered Address'
      );
      return;
    }
    onUpdateEntityLinks(parsed);
    setParseMessage(`Mapped ${parsed.length} director-company records into graph.`);
  };

  const handleFileUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const text = typeof reader.result === 'string' ? reader.result : '';
      setCsvText(text);
      const parsed = parseMcaCsvText(text);
      if (parsed.length > 0) {
        onUpdateEntityLinks(parsed);
        setParseMessage(`Imported ${parsed.length} rows from ${file.name}.`);
      } else {
        setParseMessage(`Could not parse rows from ${file.name}.`);
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleAddManualRow = (e: FormEvent) => {
    e.preventDefault();
    if (!manualCompany.trim() || !manualDirector.trim()) {
      setParseMessage('Both Company Name and Director Name are required.');
      return;
    }
    const newRow: EntityDirectorLink = {
      id: `link_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      companyName: manualCompany.trim(),
      directorName: manualDirector.trim(),
      din: manualDin.trim().toUpperCase(),
      registeredAddress: manualAddress.trim(),
    };
    onUpdateEntityLinks([...entityLinks, newRow]);
    setManualDirector('');
    setManualDin('');
    setParseMessage(null);
  };

  const handleRemoveRow = (id: string) => {
    onUpdateEntityLinks(entityLinks.filter((r) => r.id !== id));
  };

  const handleResetLayout = () => {
    const initial: Record<string, { x: number; y: number }> = {};
    for (const node of analysis.nodes) {
      initial[node.id] = { x: node.x, y: node.y };
    }
    setNodePositions(initial);
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  const handleSvgPointerDown = (e: PointerEvent<SVGSVGElement>) => {
    if (e.target === svgRef.current) {
      dragStateRef.current = {
        mode: 'pan',
        startClientX: e.clientX,
        startClientY: e.clientY,
        origX: pan.x,
        origY: pan.y,
      };
      svgRef.current?.setPointerCapture(e.pointerId);
    }
  };

  const handleNodePointerDown = (
    e: PointerEvent<SVGGElement>,
    nodeId: string
  ) => {
    e.stopPropagation();
    const pos = nodePositions[nodeId] ?? { x: 460, y: 260 };
    dragStateRef.current = {
      mode: 'node',
      nodeId,
      startClientX: e.clientX,
      startClientY: e.clientY,
      origX: pos.x,
      origY: pos.y,
    };
    setSelectedNodeId(nodeId);
    svgRef.current?.setPointerCapture(e.pointerId);
  };

  const handleSvgPointerMove = (e: PointerEvent<SVGSVGElement>) => {
    const drag = dragStateRef.current;
    if (!drag.mode) return;

    const svgEl = svgRef.current;
    const rect = svgEl?.getBoundingClientRect();
    const scaleX = rect ? 920 / rect.width : 1;
    const scaleY = rect ? 520 / rect.height : 1;

    if (drag.mode === 'node' && drag.nodeId) {
      const dx = ((e.clientX - drag.startClientX) * scaleX) / zoom;
      const dy = ((e.clientY - drag.startClientY) * scaleY) / zoom;
      setNodePositions((prev) => ({
        ...prev,
        [drag.nodeId!]: {
          x: Math.max(40, Math.min(880, drag.origX + dx)),
          y: Math.max(35, Math.min(485, drag.origY + dy)),
        },
      }));
    } else if (drag.mode === 'pan') {
      const dx = (e.clientX - drag.startClientX) * scaleX;
      const dy = (e.clientY - drag.startClientY) * scaleY;
      setPan({ x: drag.origX + dx, y: drag.origY + dy });
    }
  };

  const handleSvgPointerUp = (e: PointerEvent<SVGSVGElement>) => {
    if (dragStateRef.current.mode) {
      dragStateRef.current.mode = null;
      try {
        svgRef.current?.releasePointerCapture(e.pointerId);
      } catch {
        // Ignore if not captured
      }
    }
  };

  const handleAppendNexusSummary = () => {
    const lines: string[] = [];
    if (analysis.sharedDirectors.length > 0) {
      lines.push('- MCA21 Shared Directorship Linkages Identified:');
      for (const sd of analysis.sharedDirectors) {
        lines.push(
          `  * ${sd.name}${sd.din ? ` (DIN: ${sd.din})` : ''} serves across ${
            sd.companies.length
          } entities: ${sd.companies.join('; ')}`
        );
      }
    }
    if (analysis.sharedAddresses.length > 0) {
      lines.push('- Common Registered Office Addresses Flagged:');
      for (const sa of analysis.sharedAddresses) {
        lines.push(
          `  * "${sa.address}" is shared by ${sa.companies.length} entities: ${sa.companies.join(
            '; '
          )}`
        );
      }
    }
    if (lines.length === 0) {
      lines.push(
        `- MCA21 Relationship Mapping reviewed (${entityLinks.length} links): no shared directors or common registered addresses detected in current dataset.`
      );
    }

    onAppendFindingsToMemo(lines.join('\n'));
    setMemoAppendedNotice(true);
    setTimeout(() => setMemoAppendedNotice(false), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Top Intake & CSV Parser Row */}
      <section
        aria-labelledby="mapper-intake-heading"
        className="bg-[#111826] border border-slate-800/90 rounded-xl p-6"
      >
        <div className="flex flex-wrap items-start justify-between gap-4 pb-5 border-b border-slate-800/80">
          <div>
            <h2
              id="mapper-intake-heading"
              className="text-lg font-semibold text-slate-100 tracking-tight"
            >
              Entity & Director Relationship Mapper
            </h2>
            <p className="mt-1 text-sm text-slate-400">
              Upload or paste MCA21 director-company rows to map shared directors and common registered addresses.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv,.txt"
              onChange={handleFileUpload}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-200 bg-[#090D16] border border-slate-700/80 hover:border-slate-500 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5 text-blue-400" aria-hidden="true" />
              Upload CSV
            </button>
            <button
              type="button"
              onClick={handleLoadSampleCsv}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-blue-300 bg-blue-600/15 border border-blue-500/40 hover:bg-blue-600/25 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" aria-hidden="true" />
              Load Sample MCA21 Network
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pt-5">
          {/* Bulk CSV Paste */}
          <div className="lg:col-span-6 space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <label
                htmlFor="mca-csv-textarea"
                className="text-xs font-medium text-slate-300"
              >
                Paste MCA21 CSV / Tab-Separated Rows
              </label>
              <span className="text-[11px] font-mono text-slate-500">
                Company, Director, DIN, Address
              </span>
            </div>
            <textarea
              id="mca-csv-textarea"
              rows={4}
              value={csvText}
              onChange={(e) => setCsvText(e.target.value)}
              placeholder={`ABC Infra Pvt Ltd, Ramesh Sharma, 01234567, "402 Peninsula Park, Mumbai"\nHorizon Buildcon LLP, Ramesh Sharma, 01234567, "402 Peninsula Park, Mumbai"`}
              className="w-full bg-[#090D16] border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-slate-200 placeholder:text-slate-600 leading-relaxed focus:outline-none focus:border-blue-500/80 focus:ring-2 focus:ring-blue-500/20"
            />
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs text-slate-400">
                {parseMessage ?? `${entityLinks.length} records currently mapped`}
              </span>
              <button
                type="button"
                onClick={handleParsePaste}
                className="px-3.5 py-1.5 text-xs font-medium text-white bg-blue-600 hover:bg-blue-500 rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                Parse & Map Network
              </button>
            </div>
          </div>

          {/* Manual Single-Row Entry */}
          <form
            onSubmit={handleAddManualRow}
            className="lg:col-span-6 bg-[#0D131F] border border-slate-800/80 rounded-lg p-4 space-y-3"
          >
            <div className="text-xs font-medium text-slate-300">
              Add Individual Director-Entity Link
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label
                  htmlFor="manual-company"
                  className="block text-[11px] text-slate-400 mb-1"
                >
                  Company Name
                </label>
                <input
                  id="manual-company"
                  type="text"
                  value={manualCompany}
                  onChange={(e) => setManualCompany(e.target.value)}
                  placeholder="e.g., ABC Infra Pvt Ltd"
                  className="w-full bg-[#090D16] border border-slate-800 rounded-md px-2.5 py-1.5 text-xs text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-blue-500/80"
                />
              </div>
              <div>
                <label
                  htmlFor="manual-director"
                  className="block text-[11px] text-slate-400 mb-1"
                >
                  Director / Signatory Name
                </label>
                <input
                  id="manual-director"
                  type="text"
                  value={manualDirector}
                  onChange={(e) => setManualDirector(e.target.value)}
                  placeholder="e.g., Ramesh Sharma"
                  className="w-full bg-[#090D16] border border-slate-800 rounded-md px-2.5 py-1.5 text-xs text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-blue-500/80"
                />
              </div>
              <div>
                <label
                  htmlFor="manual-din"
                  className="block text-[11px] text-slate-400 mb-1"
                >
                  DIN (Optional)
                </label>
                <input
                  id="manual-din"
                  type="text"
                  value={manualDin}
                  onChange={(e) => setManualDin(e.target.value)}
                  placeholder="01234567"
                  className="w-full bg-[#090D16] border border-slate-800 rounded-md px-2.5 py-1.5 text-xs font-mono text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-blue-500/80"
                />
              </div>
              <div>
                <label
                  htmlFor="manual-address"
                  className="block text-[11px] text-slate-400 mb-1"
                >
                  Registered Address
                </label>
                <input
                  id="manual-address"
                  type="text"
                  value={manualAddress}
                  onChange={(e) => setManualAddress(e.target.value)}
                  placeholder="402 Peninsula Park, Mumbai"
                  className="w-full bg-[#090D16] border border-slate-800 rounded-md px-2.5 py-1.5 text-xs text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-blue-500/80"
                />
              </div>
            </div>
            <div className="flex justify-end">
              <button
                type="submit"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-100 bg-[#182235] border border-slate-700 hover:border-slate-500 rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5 text-blue-400" aria-hidden="true" />
                Add Link
              </button>
            </div>
          </form>
        </div>
      </section>

      {/* Interactive Node-Link Graph + Inspector */}
      <section
        aria-labelledby="graph-canvas-heading"
        className="bg-[#111826] border border-slate-800/90 rounded-xl overflow-hidden"
      >
        <div className="px-6 py-4 border-b border-slate-800/80 flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-4">
            <h3
              id="graph-canvas-heading"
              className="text-base font-semibold text-slate-100"
            >
              Interactive Network Graph
            </h3>
            <span className="text-xs font-mono tabular-nums text-slate-400">
              {analysis.sharedDirectors.length} shared directors ·{' '}
              {analysis.sharedAddresses.length} common addresses
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div
              role="tablist"
              aria-label="Highlight network relationships"
              className="flex items-center gap-1 bg-[#090D16] border border-slate-800 rounded-lg p-1"
            >
              <button
                type="button"
                role="tab"
                aria-selected={filterMode === 'all'}
                onClick={() => setFilterMode('all')}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  filterMode === 'all'
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                All Nodes
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={filterMode === 'shared_directors'}
                onClick={() => setFilterMode('shared_directors')}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  filterMode === 'shared_directors'
                    ? 'bg-amber-600 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Shared Directors ({analysis.sharedDirectors.length})
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={filterMode === 'shared_addresses'}
                onClick={() => setFilterMode('shared_addresses')}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  filterMode === 'shared_addresses'
                    ? 'bg-rose-600 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Common Addresses ({analysis.sharedAddresses.length})
              </button>
            </div>

            <div className="flex items-center gap-1 bg-[#090D16] border border-slate-800 rounded-lg p-1">
              <button
                type="button"
                onClick={() => setZoom((z) => Math.min(2, Number((z + 0.2).toFixed(1))))}
                aria-label="Zoom in"
                className="p-1 text-slate-400 hover:text-slate-100 rounded cursor-pointer"
              >
                <ZoomIn className="w-3.5 h-3.5" aria-hidden="true" />
              </button>
              <button
                type="button"
                onClick={() => setZoom((z) => Math.max(0.6, Number((z - 0.2).toFixed(1))))}
                aria-label="Zoom out"
                className="p-1 text-slate-400 hover:text-slate-100 rounded cursor-pointer"
              >
                <ZoomOut className="w-3.5 h-3.5" aria-hidden="true" />
              </button>
              <button
                type="button"
                onClick={handleResetLayout}
                aria-label="Reset graph layout"
                className="p-1 text-slate-400 hover:text-slate-100 rounded cursor-pointer"
              >
                <Maximize2 className="w-3.5 h-3.5" aria-hidden="true" />
              </button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-12">
          {/* SVG Canvas */}
          <div className="xl:col-span-8 bg-[#090D16] relative border-b xl:border-b-0 xl:border-r border-slate-800/80">
            {entityLinks.length === 0 ? (
              <div className="h-[460px] flex flex-col items-center justify-center px-6 text-center">
                <GitBranch className="w-8 h-8 text-slate-600 mb-3" aria-hidden="true" />
                <p className="text-sm font-medium text-slate-300">
                  No MCA21 entity-director links mapped yet
                </p>
                <p className="mt-1 text-xs text-slate-500 max-w-md">
                  Upload a CSV, paste MCA21 director data above, or load the sample network to inspect shared directorships and common registered addresses.
                </p>
                <button
                  type="button"
                  onClick={handleLoadSampleCsv}
                  className="mt-4 px-4 py-2 text-xs font-medium text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors cursor-pointer"
                >
                  Load Sample MCA21 Network
                </button>
              </div>
            ) : (
              <>
                <svg
                  ref={svgRef}
                  viewBox="0 0 920 520"
                  onPointerDown={handleSvgPointerDown}
                  onPointerMove={handleSvgPointerMove}
                  onPointerUp={handleSvgPointerUp}
                  className="w-full h-[460px] sm:h-[520px] select-none touch-none cursor-grab active:cursor-grabbing"
                >
                  <defs>
                    <pattern
                      id="grid-dots"
                      width="24"
                      height="24"
                      patternUnits="userSpaceOnUse"
                    >
                      <circle cx="2" cy="2" r="1" fill="#1E293B" />
                    </pattern>
                  </defs>
                  <rect width="920" height="520" fill="url(#grid-dots)" />

                  <g
                    transform={`translate(${pan.x + 460 * (1 - zoom)}, ${
                      pan.y + 260 * (1 - zoom)
                    }) scale(${zoom})`}
                  >
                    {/* Edges */}
                    {visibleGraph.edges.map((edge) => {
                      const s = nodePositions[edge.source];
                      const t = nodePositions[edge.target];
                      if (!s || !t) return null;

                      const isSelectedEdge =
                        selectedNodeId === edge.source ||
                        selectedNodeId === edge.target;

                      const strokeColor =
                        edge.kind === 'shared_address'
                          ? '#F43F5E'
                          : edge.isFlagged
                            ? '#F59E0B'
                            : '#334155';

                      return (
                        <line
                          key={edge.id}
                          x1={s.x}
                          y1={s.y}
                          x2={t.x}
                          y2={t.y}
                          stroke={strokeColor}
                          strokeWidth={isSelectedEdge ? 2.4 : edge.isFlagged ? 1.8 : 1.2}
                          strokeDasharray={
                            edge.kind === 'shared_address' ? '5 4' : undefined
                          }
                          strokeOpacity={
                            selectedNodeId && !isSelectedEdge ? 0.25 : 0.85
                          }
                        />
                      );
                    })}

                    {/* Nodes */}
                    {visibleGraph.nodes.map((node) => {
                      const pos = nodePositions[node.id] ?? { x: node.x, y: node.y };
                      const isSelected = selectedNodeId === node.id;
                      const isDimmed =
                        selectedNodeId !== null &&
                        !isSelected &&
                        !node.connectedIds.includes(selectedNodeId);

                      return (
                        <g
                          key={node.id}
                          transform={`translate(${pos.x}, ${pos.y})`}
                          onPointerDown={(e) => handleNodePointerDown(e, node.id)}
                          style={{ opacity: isDimmed ? 0.32 : 1 }}
                          className="cursor-pointer"
                        >
                          {node.kind === 'company' && (
                            <>
                              <rect
                                x={-76}
                                y={-22}
                                width={152}
                                height={44}
                                rx={8}
                                fill={node.isFlagged ? '#1E1B2E' : '#131D2E'}
                                stroke={
                                  isSelected
                                    ? '#60A5FA'
                                    : node.isFlagged
                                      ? '#F43F5E'
                                      : '#3B82F6'
                                }
                                strokeWidth={isSelected ? 2.5 : 1.5}
                              />
                              <text
                                textAnchor="middle"
                                y={-2}
                                fill="#F1F5F9"
                                fontSize={11}
                                fontWeight={600}
                                fontFamily="Plus Jakarta Sans, sans-serif"
                              >
                                {truncateLabel(node.label, 22)}
                              </text>
                              <text
                                textAnchor="middle"
                                y={13}
                                fill={node.isFlagged ? '#FDA4AF' : '#94A3B8'}
                                fontSize={9.5}
                                fontFamily="JetBrains Mono, monospace"
                              >
                                {node.isFlagged ? 'Co-located Entity' : 'Company'}
                              </text>
                            </>
                          )}

                          {node.kind === 'director' && (
                            <>
                              <circle
                                r={26}
                                fill={node.isFlagged ? '#2A1D0D' : '#131B29'}
                                stroke={
                                  isSelected
                                    ? '#60A5FA'
                                    : node.isFlagged
                                      ? '#F59E0B'
                                      : '#64748B'
                                }
                                strokeWidth={isSelected ? 2.5 : node.isFlagged ? 2 : 1.4}
                              />
                              <text
                                textAnchor="middle"
                                y={-2}
                                fill={node.isFlagged ? '#FDE68A' : '#E2E8F0'}
                                fontSize={10}
                                fontWeight={600}
                                fontFamily="Public Sans, sans-serif"
                              >
                                {truncateLabel(node.label, 14)}
                              </text>
                              <text
                                textAnchor="middle"
                                y={11}
                                fill={node.isFlagged ? '#FBBF24' : '#94A3B8'}
                                fontSize={8.5}
                                fontFamily="JetBrains Mono, monospace"
                              >
                                {node.isFlagged ? 'SHARED' : node.sublabel || 'Director'}
                              </text>
                            </>
                          )}

                          {node.kind === 'address' && (
                            <>
                              <polygon
                                points="0,-28 74,0 0,28 -74,0"
                                fill="#2B121B"
                                stroke={isSelected ? '#60A5FA' : '#F43F5E'}
                                strokeWidth={isSelected ? 2.5 : 1.8}
                              />
                              <text
                                textAnchor="middle"
                                y={-2}
                                fill="#FFE4E6"
                                fontSize={9.5}
                                fontWeight={600}
                                fontFamily="Public Sans, sans-serif"
                              >
                                {truncateLabel(node.label, 18)}
                              </text>
                              <text
                                textAnchor="middle"
                                y={11}
                                fill="#FDA4AF"
                                fontSize={8.5}
                                fontFamily="JetBrains Mono, monospace"
                              >
                                {node.sublabel}
                              </text>
                            </>
                          )}
                        </g>
                      );
                    })}
                  </g>
                </svg>

                {/* Legend Strip */}
                <div className="px-4 py-2.5 border-t border-slate-800/80 bg-[#0C121E] flex flex-wrap items-center justify-between gap-3 text-[11px] text-slate-400">
                  <div className="flex flex-wrap items-center gap-4">
                    <span className="inline-flex items-center gap-1.5">
                      <span className="w-3 h-2.5 rounded-xs border border-blue-500 bg-[#131D2E] inline-block" />
                      Company
                    </span>
                    <span className="inline-flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full border border-amber-500 bg-[#2A1D0D] inline-block" />
                      Shared Director (2+ entities)
                    </span>
                    <span className="inline-flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rotate-45 border border-rose-500 bg-[#2B121B] inline-block" />
                      Common Registered Address
                    </span>
                  </div>
                  <span className="font-mono text-slate-500">
                    Drag nodes to arrange · Click to inspect
                  </span>
                </div>
              </>
            )}
          </div>

          {/* Right Inspector & Detected Nexus Summary */}
          <div className="xl:col-span-4 p-5 space-y-5 flex flex-col justify-between bg-[#111826]">
            <div className="space-y-5">
              {/* Selected Node Detail */}
              <div>
                <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2.5">
                  Node Inspector
                </h4>
                {selectedNode ? (
                  <div className="bg-[#090D16] border border-slate-800 rounded-lg p-3.5 space-y-2">
                    <div className="text-xs font-mono text-blue-400">
                      {selectedNode.kind === 'company'
                        ? 'Corporate Entity'
                        : selectedNode.kind === 'director'
                          ? 'Director / Signatory'
                          : 'Shared Registered Address'}
                    </div>
                    <div className="text-sm font-semibold text-slate-100">
                      {selectedNode.label}
                    </div>
                    {selectedNode.sublabel && (
                      <div className="text-xs font-mono text-slate-400">
                        {selectedNode.sublabel}
                      </div>
                    )}
                    {selectedNode.flagReason && (
                      <div className="text-xs font-medium text-amber-300 pt-1">
                        Flag: {selectedNode.flagReason}
                      </div>
                    )}
                    <div className="pt-2 border-t border-slate-800/80">
                      <div className="text-[11px] text-slate-500 mb-1">
                        Direct Connections ({selectedNode.connectedIds.length})
                      </div>
                      <ul className="space-y-1 text-xs text-slate-300">
                        {selectedNode.connectedIds.map((cid) => {
                          const target = analysis.nodes.find((n) => n.id === cid);
                          if (!target) return null;
                          return (
                            <li key={cid}>
                              <button
                                type="button"
                                onClick={() => setSelectedNodeId(target.id)}
                                className="hover:text-blue-400 transition-colors text-left cursor-pointer"
                              >
                                → {target.label}
                              </button>
                            </li>
                          );
                        })}
                      </ul>
                    </div>
                  </div>
                ) : (
                  <div className="bg-[#090D16] border border-slate-800/70 rounded-lg p-3.5 text-xs text-slate-500">
                    Click any node on the graph to inspect linked companies, DINs, and shared-nexus flags.
                  </div>
                )}
              </div>

              {/* Automated Nexus Detection Breakdown */}
              <div className="space-y-3">
                <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                  Detected Nexus Flags
                </h4>

                <div className="space-y-2">
                  <div className="text-xs font-medium text-amber-300">
                    Shared Directors ({analysis.sharedDirectors.length})
                  </div>
                  {analysis.sharedDirectors.length === 0 ? (
                    <p className="text-xs text-slate-500">
                      None detected across current rows.
                    </p>
                  ) : (
                    <ul className="space-y-2">
                      {analysis.sharedDirectors.map((sd) => (
                        <li
                          key={sd.key}
                          className="bg-[#090D16] border border-slate-800 rounded-md px-3 py-2 text-xs"
                        >
                          <div className="font-medium text-slate-200">
                            {sd.name}
                            {sd.din && (
                              <span className="ml-2 font-mono text-[11px] text-slate-400">
                                DIN {sd.din}
                              </span>
                            )}
                          </div>
                          <div className="mt-0.5 text-[11px] text-slate-400">
                            {sd.companies.join(' · ')}
                          </div>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>

                <div className="space-y-2 pt-2">
                  <div className="text-xs font-medium text-rose-300">
                    Common Registered Addresses ({analysis.sharedAddresses.length})
                  </div>
                  {analysis.sharedAddresses.length === 0 ? (
                    <p className="text-xs text-slate-500">
                      No shared addresses detected across current rows.
                    </p>
                  ) : (
                    <ul className="space-y-2">
                      {analysis.sharedAddresses.map((sa) => (
                        <li
                          key={sa.key}
                          className="bg-[#090D16] border border-slate-800 rounded-md px-3 py-2 text-xs"
                        >
                          <div className="font-medium text-slate-200">
                            {sa.address}
                          </div>
                          <div className="mt-0.5 text-[11px] text-slate-400">
                            {sa.companies.join(' · ')}
                          </div>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800/80 space-y-2">
              <button
                type="button"
                onClick={handleAppendNexusSummary}
                disabled={entityLinks.length === 0}
                className="w-full inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-medium text-white bg-blue-600 hover:bg-blue-500 disabled:opacity-50 rounded-lg transition-colors cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" aria-hidden="true" />
                Append Nexus Summary to Analyst Memo
              </button>
              {memoAppendedNotice && (
                <p className="text-xs text-emerald-400 text-center">
                  Nexus findings appended to Corporate Background in Analyst Memo.
                </p>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Mapped Rows Table */}
      {entityLinks.length > 0 && (
        <section
          aria-labelledby="mapped-rows-heading"
          className="bg-[#111826] border border-slate-800/90 rounded-xl overflow-hidden"
        >
          <div className="px-6 py-4 border-b border-slate-800/80 flex items-center justify-between gap-4">
            <h3
              id="mapped-rows-heading"
              className="text-sm font-semibold text-slate-100"
            >
              Mapped MCA21 Records ({entityLinks.length})
            </h3>
            <button
              type="button"
              onClick={() => onUpdateEntityLinks([])}
              className="text-xs font-medium text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
            >
              Clear all rows
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse min-w-[640px]">
              <thead>
                <tr className="bg-[#0D131F] border-b border-slate-800/80 text-[11px] font-semibold text-slate-400">
                  <th className="py-2.5 px-4">Company Name</th>
                  <th className="py-2.5 px-4">Director Name</th>
                  <th className="py-2.5 px-4">DIN</th>
                  <th className="py-2.5 px-4">Registered Address</th>
                  <th className="py-2.5 px-4 text-right">Remove</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/70 text-xs">
                {entityLinks.map((row) => (
                  <tr key={row.id} className="hover:bg-[#141D2E]/50">
                    <td className="py-2.5 px-4 font-medium text-slate-200">
                      {row.companyName}
                    </td>
                    <td className="py-2.5 px-4 text-slate-300">
                      {row.directorName}
                    </td>
                    <td className="py-2.5 px-4 font-mono tabular-nums text-slate-400">
                      {row.din || '—'}
                    </td>
                    <td className="py-2.5 px-4 text-slate-400">
                      {row.registeredAddress || '—'}
                    </td>
                    <td className="py-2.5 px-4 text-right">
                      <button
                        type="button"
                        onClick={() => handleRemoveRow(row.id)}
                        aria-label={`Remove ${row.directorName} at ${row.companyName}`}
                        className="p-1 text-slate-500 hover:text-rose-400 transition-colors rounded cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </div>
  );
}
