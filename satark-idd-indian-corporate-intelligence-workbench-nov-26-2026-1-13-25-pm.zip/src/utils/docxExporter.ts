import {
  AlignmentType,
  BorderStyle,
  Document,
  Footer,
  Header,
  HeadingLevel,
  Packer,
  PageNumber,
  Paragraph,
  ShadingType,
  Table,
  TableCell,
  TableRow,
  TextRun,
  WidthType,
} from 'docx';
import {
  AnalystNotes,
  InvestigationSubject,
  InvestigationType,
  OsintQueryItem,
} from '../types/investigation';
import { analyzeIdentifier, getInvestigationTypeMeta } from './osintBuilder';

function buildParagraphsFromText(text: string, emptyFallback: string): Paragraph[] {
  const trimmed = text.trim();
  if (!trimmed) {
    return [
      new Paragraph({
        spacing: { before: 80, after: 140 },
        children: [
          new TextRun({
            text: emptyFallback,
            italics: true,
            color: '64748B',
            size: 21,
            font: 'Calibri',
          }),
        ],
      }),
    ];
  }

  return trimmed.split(/\r?\n/).map((line) => {
    const cleanLine = line.trim();
    const isBullet = /^[-•*]\s+/.test(cleanLine);
    if (isBullet) {
      return new Paragraph({
        bullet: { level: 0 },
        spacing: { before: 40, after: 80, line: 276 },
        children: [
          new TextRun({
            text: cleanLine.replace(/^[-•*]\s+/, ''),
            color: '1E293B',
            size: 21,
            font: 'Calibri',
          }),
        ],
      });
    }
    return new Paragraph({
      spacing: { before: 40, after: 100, line: 276 },
      children: [
        new TextRun({
          text: cleanLine || ' ',
          color: '1E293B',
          size: 21,
          font: 'Calibri',
        }),
      ],
    });
  });
}

function makeSectionHeading(numberLabel: string, title: string): Paragraph {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 280, after: 120 },
    border: {
      bottom: {
        color: 'CBD5E1',
        space: 4,
        style: BorderStyle.SINGLE,
        size: 6,
      },
    },
    children: [
      new TextRun({
        text: `${numberLabel}  `,
        bold: true,
        color: '1D4ED8',
        size: 24,
        font: 'Calibri',
      }),
      new TextRun({
        text: title,
        bold: true,
        color: '0F172A',
        size: 24,
        font: 'Calibri',
      }),
    ],
  });
}

function makeMetadataRow(label: string, value: string, shade = false): TableRow {
  const borderSpec = {
    color: 'CBD5E1',
    size: 4,
    style: BorderStyle.SINGLE,
  };

  return new TableRow({
    children: [
      new TableCell({
        width: { size: 32, type: WidthType.PERCENTAGE },
        shading: shade
          ? { type: ShadingType.CLEAR, fill: 'F8FAFC', color: 'auto' }
          : { type: ShadingType.CLEAR, fill: 'F1F5F9', color: 'auto' },
        borders: { top: borderSpec, bottom: borderSpec, left: borderSpec, right: borderSpec },
        margins: { top: 85, bottom: 85, left: 130, right: 130 },
        children: [
          new Paragraph({
            children: [
              new TextRun({
                text: label,
                bold: true,
                color: '334155',
                size: 20,
                font: 'Calibri',
              }),
            ],
          }),
        ],
      }),
      new TableCell({
        width: { size: 68, type: WidthType.PERCENTAGE },
        shading: { type: ShadingType.CLEAR, fill: 'FFFFFF', color: 'auto' },
        borders: { top: borderSpec, bottom: borderSpec, left: borderSpec, right: borderSpec },
        margins: { top: 85, bottom: 85, left: 130, right: 130 },
        children: [
          new Paragraph({
            children: [
              new TextRun({
                text: value,
                color: '0F172A',
                size: 20,
                font: 'Calibri',
              }),
            ],
          }),
        ],
      }),
    ],
  });
}

function scoreLabel(score: number): string {
  if (score === 0) return '0 / 3 (Clear)';
  if (score === 1) return '1 / 3 (Low)';
  if (score === 2) return '2 / 3 (Moderate)';
  return '3 / 3 (High / Material)';
}

export async function exportInvestigationMemoDocx(params: {
  subject: InvestigationSubject;
  investigationType: InvestigationType;
  notes: AnalystNotes;
  osintItems: OsintQueryItem[];
  reviewedIds: string[];
}): Promise<void> {
  const { subject, investigationType, notes, osintItems, reviewedIds } = params;
  const idInfo = analyzeIdentifier(subject.dinCin);
  const typeMeta = getInvestigationTypeMeta(investigationType);
  const generatedDate = new Date().toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
  const generatedTime = new Date().toLocaleTimeString('en-IN', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  });

  const displayEntity =
    subject.companyName.trim() || subject.subjectName.trim() || 'Target Entity';
  const caseRef = notes.caseReference.trim() || 'IDD-IND-UNASSIGNED';

  const scores = notes.riskScores ?? {
    corporateGovernance: 0,
    regulatoryCompliance: 0,
    litigationInsolvency: 0,
    adverseMediaEnforcement: 0,
  };
  const compositeScore =
    scores.corporateGovernance +
    scores.regulatoryCompliance +
    scores.litigationInsolvency +
    scores.adverseMediaEnforcement;

  const cellBorder = {
    color: 'CBD5E1',
    size: 4,
    style: BorderStyle.SINGLE,
  };

  // Source Verification Table (Kroll / A&M standard format)
  const citations = notes.citations ?? [];
  const citationRows: TableRow[] = [
    new TableRow({
      tableHeader: true,
      children: [
        new TableCell({
          width: { size: 7, type: WidthType.PERCENTAGE },
          shading: { type: ShadingType.CLEAR, fill: '0F172A', color: 'auto' },
          margins: { top: 85, bottom: 85, left: 90, right: 90 },
          children: [
            new Paragraph({
              alignment: AlignmentType.CENTER,
              children: [
                new TextRun({ text: '#', bold: true, color: 'FFFFFF', size: 18, font: 'Calibri' }),
              ],
            }),
          ],
        }),
        new TableCell({
          width: { size: 49, type: WidthType.PERCENTAGE },
          shading: { type: ShadingType.CLEAR, fill: '0F172A', color: 'auto' },
          margins: { top: 85, bottom: 85, left: 100, right: 100 },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: 'Source URL & Reference',
                  bold: true,
                  color: 'FFFFFF',
                  size: 18,
                  font: 'Calibri',
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          width: { size: 18, type: WidthType.PERCENTAGE },
          shading: { type: ShadingType.CLEAR, fill: '0F172A', color: 'auto' },
          margins: { top: 85, bottom: 85, left: 90, right: 90 },
          children: [
            new Paragraph({
              alignment: AlignmentType.CENTER,
              children: [
                new TextRun({
                  text: 'Date Accessed',
                  bold: true,
                  color: 'FFFFFF',
                  size: 18,
                  font: 'Calibri',
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          width: { size: 26, type: WidthType.PERCENTAGE },
          shading: { type: ShadingType.CLEAR, fill: '0F172A', color: 'auto' },
          margins: { top: 85, bottom: 85, left: 90, right: 90 },
          children: [
            new Paragraph({
              alignment: AlignmentType.CENTER,
              children: [
                new TextRun({
                  text: 'Reliability Rating',
                  bold: true,
                  color: 'FFFFFF',
                  size: 18,
                  font: 'Calibri',
                }),
              ],
            }),
          ],
        }),
      ],
    }),
    ...(citations.length > 0
      ? citations.map((citation, idx) => {
          const fill = idx % 2 === 0 ? 'FFFFFF' : 'F8FAFC';
          const ratingColor =
            citation.reliability === 'Primary Regulatory'
              ? '15803D'
              : citation.reliability === 'Reputable Media'
                ? '1D4ED8'
                : 'B45309';

          return new TableRow({
            children: [
              new TableCell({
                shading: { type: ShadingType.CLEAR, fill, color: 'auto' },
                borders: { top: cellBorder, bottom: cellBorder, left: cellBorder, right: cellBorder },
                margins: { top: 80, bottom: 80, left: 90, right: 90 },
                children: [
                  new Paragraph({
                    alignment: AlignmentType.CENTER,
                    children: [
                      new TextRun({
                        text: String(idx + 1).padStart(2, '0'),
                        color: '475569',
                        size: 18,
                        font: 'Consolas',
                      }),
                    ],
                  }),
                ],
              }),
              new TableCell({
                shading: { type: ShadingType.CLEAR, fill, color: 'auto' },
                borders: { top: cellBorder, bottom: cellBorder, left: cellBorder, right: cellBorder },
                margins: { top: 80, bottom: 80, left: 100, right: 100 },
                children: [
                  ...(citation.title.trim()
                    ? [
                        new Paragraph({
                          children: [
                            new TextRun({
                              text: citation.title.trim(),
                              bold: true,
                              color: '0F172A',
                              size: 18,
                              font: 'Calibri',
                            }),
                          ],
                        }),
                      ]
                    : []),
                  new Paragraph({
                    spacing: { before: citation.title.trim() ? 30 : 0 },
                    children: [
                      new TextRun({
                        text: citation.url.trim() || 'URL not specified',
                        color: '1D4ED8',
                        size: 16,
                        font: 'Consolas',
                      }),
                    ],
                  }),
                ],
              }),
              new TableCell({
                shading: { type: ShadingType.CLEAR, fill, color: 'auto' },
                borders: { top: cellBorder, bottom: cellBorder, left: cellBorder, right: cellBorder },
                margins: { top: 80, bottom: 80, left: 90, right: 90 },
                children: [
                  new Paragraph({
                    alignment: AlignmentType.CENTER,
                    children: [
                      new TextRun({
                        text: citation.dateAccessed || generatedDate,
                        color: '334155',
                        size: 18,
                        font: 'Consolas',
                      }),
                    ],
                  }),
                ],
              }),
              new TableCell({
                shading: { type: ShadingType.CLEAR, fill, color: 'auto' },
                borders: { top: cellBorder, bottom: cellBorder, left: cellBorder, right: cellBorder },
                margins: { top: 80, bottom: 80, left: 90, right: 90 },
                children: [
                  new Paragraph({
                    alignment: AlignmentType.CENTER,
                    children: [
                      new TextRun({
                        text: citation.reliability,
                        bold: true,
                        color: ratingColor,
                        size: 18,
                        font: 'Calibri',
                      }),
                    ],
                  }),
                ],
              }),
            ],
          });
        })
      : [
          new TableRow({
            children: [
              new TableCell({
                columnSpan: 4,
                shading: { type: ShadingType.CLEAR, fill: 'F8FAFC', color: 'auto' },
                borders: { top: cellBorder, bottom: cellBorder, left: cellBorder, right: cellBorder },
                margins: { top: 100, bottom: 100, left: 100, right: 100 },
                children: [
                  new Paragraph({
                    alignment: AlignmentType.CENTER,
                    children: [
                      new TextRun({
                        text: 'No source citations logged in the Source Verification Table yet.',
                        italics: true,
                        color: '64748B',
                        size: 18,
                        font: 'Calibri',
                      }),
                    ],
                  }),
                ],
              }),
            ],
          }),
        ]),
  ];

  // OSINT Screening Audit Log Table
  const auditRows: TableRow[] = [
    new TableRow({
      tableHeader: true,
      children: [
        new TableCell({
          width: { size: 22, type: WidthType.PERCENTAGE },
          shading: { type: ShadingType.CLEAR, fill: '0F172A', color: 'auto' },
          margins: { top: 85, bottom: 85, left: 100, right: 100 },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: 'Registry / Vertical',
                  bold: true,
                  color: 'FFFFFF',
                  size: 18,
                  font: 'Calibri',
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          width: { size: 60, type: WidthType.PERCENTAGE },
          shading: { type: ShadingType.CLEAR, fill: '0F172A', color: 'auto' },
          margins: { top: 85, bottom: 85, left: 100, right: 100 },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: 'OSINT Search Scope & Query',
                  bold: true,
                  color: 'FFFFFF',
                  size: 18,
                  font: 'Calibri',
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          width: { size: 18, type: WidthType.PERCENTAGE },
          shading: { type: ShadingType.CLEAR, fill: '0F172A', color: 'auto' },
          margins: { top: 85, bottom: 85, left: 100, right: 100 },
          children: [
            new Paragraph({
              alignment: AlignmentType.CENTER,
              children: [
                new TextRun({
                  text: 'Analyst Status',
                  bold: true,
                  color: 'FFFFFF',
                  size: 18,
                  font: 'Calibri',
                }),
              ],
            }),
          ],
        }),
      ],
    }),
    ...osintItems.map((item, idx) => {
      const isReviewed = reviewedIds.includes(item.id);
      const fill = idx % 2 === 0 ? 'FFFFFF' : 'F8FAFC';
      return new TableRow({
        children: [
          new TableCell({
            shading: { type: ShadingType.CLEAR, fill, color: 'auto' },
            borders: { top: cellBorder, bottom: cellBorder, left: cellBorder, right: cellBorder },
            margins: { top: 80, bottom: 80, left: 100, right: 100 },
            children: [
              new Paragraph({
                children: [
                  new TextRun({
                    text: item.categoryLabel,
                    bold: true,
                    color: '1E293B',
                    size: 18,
                    font: 'Calibri',
                  }),
                ],
              }),
              new Paragraph({
                children: [
                  new TextRun({
                    text: item.registrySource,
                    color: '64748B',
                    size: 16,
                    font: 'Calibri',
                  }),
                ],
              }),
            ],
          }),
          new TableCell({
            shading: { type: ShadingType.CLEAR, fill, color: 'auto' },
            borders: { top: cellBorder, bottom: cellBorder, left: cellBorder, right: cellBorder },
            margins: { top: 80, bottom: 80, left: 100, right: 100 },
            children: [
              new Paragraph({
                children: [
                  new TextRun({
                    text: item.title,
                    bold: true,
                    color: '0F172A',
                    size: 18,
                    font: 'Calibri',
                  }),
                ],
              }),
              new Paragraph({
                spacing: { before: 40 },
                children: [
                  new TextRun({
                    text: item.query,
                    color: '475569',
                    size: 16,
                    font: 'Consolas',
                  }),
                ],
              }),
            ],
          }),
          new TableCell({
            shading: { type: ShadingType.CLEAR, fill, color: 'auto' },
            borders: { top: cellBorder, bottom: cellBorder, left: cellBorder, right: cellBorder },
            margins: { top: 80, bottom: 80, left: 100, right: 100 },
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [
                  new TextRun({
                    text: isReviewed ? 'Reviewed' : 'Pending',
                    bold: isReviewed,
                    color: isReviewed ? '15803D' : '64748B',
                    size: 18,
                    font: 'Calibri',
                  }),
                ],
              }),
            ],
          }),
        ],
      });
    }),
  ];

  const doc = new Document({
    creator: notes.analystName.trim() || 'IDD Investigator',
    title: `Integrity Due Diligence Memo — ${displayEntity}`,
    description: `Corporate Intelligence & Integrity Due Diligence Memorandum for ${displayEntity}`,
    sections: [
      {
        properties: {
          page: {
            margin: {
              top: 1080,
              bottom: 1080,
              left: 1080,
              right: 1080,
            },
          },
        },
        headers: {
          default: new Header({
            children: [
              new Paragraph({
                alignment: AlignmentType.RIGHT,
                children: [
                  new TextRun({
                    text: `PRIVILEGED & CONFIDENTIAL  |  OPENVETT IDD — INTEGRITY DUE DILIGENCE MEMORANDUM  |  ${caseRef}`,
                    color: '64748B',
                    size: 16,
                    font: 'Calibri',
                  }),
                ],
              }),
            ],
          }),
        },
        footers: {
          default: new Footer({
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [
                  new TextRun({
                    text: `Prepared via OpenVett IDD — Analyst OSINT & Regulatory Screening Workbench  ·  Generated ${generatedDate}  ·  Page `,
                    color: '64748B',
                    size: 16,
                    font: 'Calibri',
                  }),
                  new TextRun({
                    children: [PageNumber.CURRENT],
                    color: '64748B',
                    size: 16,
                    font: 'Calibri',
                  }),
                  new TextRun({
                    text: ' of ',
                    color: '64748B',
                    size: 16,
                    font: 'Calibri',
                  }),
                  new TextRun({
                    children: [PageNumber.TOTAL_PAGES],
                    color: '64748B',
                    size: 16,
                    font: 'Calibri',
                  }),
                ],
              }),
            ],
          }),
        },
        children: [
          new Paragraph({
            spacing: { after: 60 },
            children: [
              new TextRun({
                text: 'OPENVETT IDD · INTEGRITY DUE DILIGENCE (IDD) MEMORANDUM',
                bold: true,
                color: '1D4ED8',
                size: 20,
                font: 'Calibri',
              }),
            ],
          }),
          new Paragraph({
            spacing: { after: 180 },
            children: [
              new TextRun({
                text: `${subject.companyName.trim() || 'Target Entity'}${
                  subject.subjectName.trim() ? ` — ${subject.subjectName.trim()}` : ''
                }`,
                bold: true,
                color: '0F172A',
                size: 36,
                font: 'Calibri',
              }),
            ],
          }),

          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: [
              makeMetadataRow('Case Reference', caseRef),
              makeMetadataRow('Investigation Mandate', typeMeta.label, true),
              makeMetadataRow(
                'Subject Individual',
                subject.subjectName.trim() || 'Not specified'
              ),
              makeMetadataRow(
                'Target Corporate Entity',
                subject.companyName.trim() || 'Not specified',
                true
              ),
              makeMetadataRow('DIN / CIN Identifier', idInfo.label),
              makeMetadataRow(
                'Overall Risk Rating',
                `${
                  notes.riskRating === 'High'
                    ? 'High Risk / Material Red Flags Identified'
                    : notes.riskRating === 'Medium'
                      ? 'Medium Risk / Requires Further Verification'
                      : notes.riskRating === 'Low'
                        ? 'Low Risk / Minor Observations'
                        : 'Clear / No Adverse Findings Noted'
                }  (Composite Score: ${compositeScore} / 12)`,
                true
              ),
              makeMetadataRow(
                'Risk Score Breakdown',
                `Governance: ${scoreLabel(scores.corporateGovernance)} · Regulatory: ${scoreLabel(
                  scores.regulatoryCompliance
                )} · Litigation/IBC: ${scoreLabel(
                  scores.litigationInsolvency
                )} · Adverse Media: ${scoreLabel(scores.adverseMediaEnforcement)}`
              ),
              makeMetadataRow(
                'Lead Investigator',
                notes.analystName.trim() || 'IDD Analyst',
                true
              ),
              makeMetadataRow('Report Timestamp', `${generatedDate} at ${generatedTime} IST`),
            ],
          }),

          makeSectionHeading('01.', 'Corporate Background'),
          ...buildParagraphsFromText(
            notes.corporateBackground,
            'No corporate background notes recorded yet.'
          ),

          makeSectionHeading('02.', 'Regulatory & Litigation Red Flags'),
          ...buildParagraphsFromText(
            notes.regulatoryLitigationRedFlags,
            'No regulatory or litigation red flags recorded yet.'
          ),

          makeSectionHeading('03.', 'Adverse Media Findings'),
          ...buildParagraphsFromText(
            notes.adverseMediaFindings,
            'No adverse media findings recorded yet.'
          ),

          makeSectionHeading('04.', 'Source Verification & Citation Table'),
          new Paragraph({
            spacing: { before: 40, after: 120 },
            children: [
              new TextRun({
                text: `Corroborating sources logged: ${citations.length} (${
                  citations.filter((c) => c.reliability === 'Primary Regulatory').length
                } Primary Regulatory, ${
                  citations.filter((c) => c.reliability === 'Reputable Media').length
                } Reputable Media, ${
                  citations.filter((c) => c.reliability === 'Unverified').length
                } Unverified).`,
                color: '334155',
                size: 20,
                font: 'Calibri',
              }),
            ],
          }),
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: citationRows,
          }),

          makeSectionHeading('05.', 'OSINT & Regulatory Screening Audit Log'),
          new Paragraph({
            spacing: { before: 40, after: 140 },
            children: [
              new TextRun({
                text: `Mandate: ${typeMeta.label}. Queries checked by analyst: ${reviewedIds.length} of ${osintItems.length} targeted Indian regulatory & public-domain OSINT vectors.`,
                color: '334155',
                size: 20,
                font: 'Calibri',
              }),
            ],
          }),
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: auditRows,
          }),
        ],
      },
    ],
  });

  const blob = await Packer.toBlob(doc);
  const safeBaseName = displayEntity
    .replace(/[^a-zA-Z0-9\s-_]/g, '')
    .trim()
    .replace(/\s+/g, '_');
  const fileName = `OpenVett_IDD_Memo_${safeBaseName || 'Dossier'}_${new Date()
    .toISOString()
    .slice(0, 10)}.docx`;

  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
