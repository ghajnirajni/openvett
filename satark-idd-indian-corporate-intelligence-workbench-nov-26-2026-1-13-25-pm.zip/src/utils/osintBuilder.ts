import {
  InvestigationSubject,
  InvestigationType,
  OsintCategoryId,
  OsintQueryItem,
} from '../types/investigation';

export interface IdentifierAnalysis {
  raw: string;
  type: 'DIN' | 'CIN' | 'LLPIN' | 'Reference' | 'None';
  label: string;
}

export const INVESTIGATION_TYPES: {
  id: InvestigationType;
  label: string;
  shortLabel: string;
  focusSummary: string;
}[] = [
  {
    id: 'pre_deal_pe',
    label: 'Pre-Deal PE Due Diligence',
    shortLabel: 'Pre-Deal PE',
    focusSummary:
      'Screens governance defaults, SEBI compliance, undisclosed IBC liabilities, related-party charges, and promoter share pledges.',
  },
  {
    id: 'promoter_bg',
    label: 'Promoter Background Check',
    shortLabel: 'Promoter Check',
    focusSummary:
      'Focuses on DIN 164(2) disqualifications, shell-company strike-offs, wilful defaulters, ED/CBI probes, PEP ties, and criminal dockets.',
  },
  {
    id: 'litigation_asset',
    label: 'Litigation & Asset Tracing',
    shortLabel: 'Litigation & Assets',
    focusSummary:
      'Targets DRT/SARFAESI attachments, PMLA property seizures, High Court execution decrees, arbitration awards, and ROC charge registries.',
  },
];

export function getInvestigationTypeMeta(type: InvestigationType) {
  return (
    INVESTIGATION_TYPES.find((item) => item.id === type) ?? INVESTIGATION_TYPES[0]
  );
}

export function analyzeIdentifier(rawInput: string): IdentifierAnalysis {
  const cleaned = rawInput.trim().toUpperCase().replace(/\s+/g, '');
  if (!cleaned) {
    return { raw: '', type: 'None', label: 'Not provided' };
  }
  if (/^\d{8}$/.test(cleaned)) {
    return { raw: cleaned, type: 'DIN', label: `DIN (${cleaned})` };
  }
  if (/^[LU]\d{5}[A-Z]{2}\d{4}[A-Z]{3}\d{6}$/.test(cleaned)) {
    return { raw: cleaned, type: 'CIN', label: `CIN (${cleaned})` };
  }
  if (/^[A-Z]{3}-?\d{4}$/.test(cleaned)) {
    return { raw: cleaned, type: 'LLPIN', label: `LLPIN (${cleaned})` };
  }
  return { raw: cleaned, type: 'Reference', label: `ID (${cleaned})` };
}

export const OSINT_CATEGORIES: { id: OsintCategoryId; label: string; shortLabel: string }[] = [
  { id: 'sebi', label: 'SEBI Enforcement Orders', shortLabel: 'SEBI' },
  { id: 'nclt', label: 'NCLT Insolvency Filings', shortLabel: 'NCLT / IBBI' },
  { id: 'ecourts', label: 'e-Courts Litigation', shortLabel: 'e-Courts' },
  { id: 'rbi', label: 'RBI Wilful Defaulters', shortLabel: 'RBI / CIBIL' },
  { id: 'ed_cbi', label: 'ED / CBI News', shortLabel: 'ED / CBI' },
  { id: 'mca21', label: 'MCA21 Corporate Records', shortLabel: 'MCA21' },
];

function buildEntityClause(subject: InvestigationSubject, includeIdentifier = false): string {
  const terms: string[] = [];
  const person = subject.subjectName.trim();
  const company = subject.companyName.trim();
  const identifier = subject.dinCin.trim();

  if (person) terms.push(`"${person}"`);
  if (company) terms.push(`"${company}"`);
  if (includeIdentifier && identifier) terms.push(`"${identifier}"`);

  if (terms.length === 0) return '""';
  if (terms.length === 1) return terms[0];
  return `(${terms.join(' OR ')})`;
}

function buildStrictPairClause(subject: InvestigationSubject): string {
  const person = subject.subjectName.trim();
  const company = subject.companyName.trim();
  if (person && company) return `("${person}" OR "${company}")`;
  if (person) return `"${person}"`;
  if (company) return `"${company}"`;
  return `"${subject.dinCin.trim()}"`;
}

function googleSearchUrl(query: string): string {
  return `https://www.google.com/search?q=${encodeURIComponent(query)}`;
}

export function buildOsintQueries(
  subject: InvestigationSubject,
  investigationType: InvestigationType = 'pre_deal_pe'
): OsintQueryItem[] {
  const entityAll = buildEntityClause(subject, true);
  const entityNames = buildStrictPairClause(subject);
  const companyOnly = subject.companyName.trim()
    ? `"${subject.companyName.trim()}"`
    : entityNames;
  const personOnly = subject.subjectName.trim()
    ? `"${subject.subjectName.trim()}"`
    : entityNames;
  const identifier = subject.dinCin.trim();

  let queries: Omit<OsintQueryItem, 'url'>[] = [];

  if (investigationType === 'pre_deal_pe') {
    queries = [
      // SEBI - PE Deal Focus
      {
        id: 'sebi-orders',
        category: 'sebi',
        categoryLabel: 'SEBI Enforcement Orders',
        registrySource: 'sebi.gov.in',
        title: 'SEBI Governance, Disclosure & LODR Violations',
        rationale:
          'Screens SEBI adjudication orders, LODR non-compliance, related-party disclosure lapses, and promoter pledge notices.',
        query: `site:sebi.gov.in ${entityAll} (LODR OR "related party" OR SAST OR adjudication OR settlement OR penalty)`,
      },
      {
        id: 'sebi-sat',
        category: 'sebi',
        categoryLabel: 'SEBI Enforcement Orders',
        registrySource: 'SAT · SEBI Circulars',
        title: 'Capital Market Restraints, ICDR & Forensic Audits',
        rationale:
          'Identifies SEBI-ordered forensic audits, fund diversion findings, and Securities Appellate Tribunal rulings.',
        query: `${entityNames} ("forensic audit" OR "diversion of funds" OR "SEBI order" OR "Securities Appellate Tribunal" OR "promoter pledge")`,
      },
      // NCLT - PE Deal Focus
      {
        id: 'nclt-ibbi',
        category: 'nclt',
        categoryLabel: 'NCLT Insolvency Filings',
        registrySource: 'nclt.gov.in · ibbi.gov.in',
        title: 'Pending IBC Section 7 / 9 Petitions & Contingent Claims',
        rationale:
          'Detects operational/financial creditor petitions on NCLT & IBBI that could trigger CIRP or impair deal closing.',
        query: `(site:nclt.gov.in OR site:ibbi.gov.in) ${entityAll} ("Section 7" OR "Section 9" OR CIRP OR "resolution plan" OR "avoidance transaction")`,
      },
      {
        id: 'nclt-nclat',
        category: 'nclt',
        categoryLabel: 'NCLT Insolvency Filings',
        registrySource: 'NCLT · NCLAT',
        title: 'Oppression, Mismanagement & Shareholder Disputes',
        rationale:
          'Surfaces Section 241/242 minority shareholder oppression petitions, demerger objections, and NCLAT stays.',
        query: `${companyOnly} ("NCLT" OR "NCLAT") ("Section 241" OR "Section 242" OR "oppression and mismanagement" OR "shareholders agreement" OR "scheme of arrangement")`,
      },
      // e-Courts - PE Deal Focus
      {
        id: 'ecourts-kanoon',
        category: 'ecourts',
        categoryLabel: 'e-Courts Litigation',
        registrySource: 'indiankanoon.org',
        title: 'Commercial Court, Tax & Contractual Disputes',
        rationale:
          'Reviews High Court & Commercial Court disputes involving indemnity, IP, GST/Income Tax appeals, or JV breaches.',
        query: `site:indiankanoon.org ${entityNames} ("Commercial Court" OR "joint venture" OR "Income Tax" OR "GST" OR "arbitration")`,
      },
      {
        id: 'ecourts-ni138',
        category: 'ecourts',
        categoryLabel: 'e-Courts Litigation',
        registrySource: 'ecourts.gov.in · Tribunals',
        title: 'Vendor Defaults, Labour & Sec 138 NI Act Exposure',
        rationale:
          'Screens district court dockets for vendor non-payment suits, cheque dishonour, and statutory labour claims.',
        query: `(site:ecourts.gov.in OR "High Court") ${entityNames} ("138 NI Act" OR "vendor" OR "recovery suit" OR "EPFO" OR "writ petition")`,
      },
      // RBI - PE Deal Focus
      {
        id: 'rbi-cibil',
        category: 'rbi',
        categoryLabel: 'RBI Wilful Defaulters',
        registrySource: 'RBI · CIBIL · Credit Ratings',
        title: 'Credit Rating Downgrades, SMA-2 & Defaulter Lists',
        rationale:
          'Identifies ICRA/CRISIL/CARE default disclosures, CIBIL suit-filed lists, and RBI wilful defaulter red flags.',
        query: `${entityAll} ("wilful defaulter" OR "SMA-2" OR "NPA" OR "rating downgraded" OR "default" OR "TransUnion CIBIL")`,
      },
      {
        id: 'rbi-drt',
        category: 'rbi',
        categoryLabel: 'RBI Wilful Defaulters',
        registrySource: 'DRT · FEMA · RBI',
        title: 'FEMA Compounding, ECB Defaults & Lender Consents',
        rationale:
          'Checks RBI FEMA compounding orders, DRT debt restructuring disputes, and lender NOC/covenant breaches.',
        query: `${entityNames} ("FEMA" OR "compounding order" OR "Reserve Bank of India" OR "DRT" OR "debt restructuring" OR "covenant breach")`,
      },
      // ED/CBI - PE Deal Focus
      {
        id: 'ed-pmla',
        category: 'ed_cbi',
        categoryLabel: 'ED / CBI News',
        registrySource: 'ED · PMLA · Tax Intelligence',
        title: 'PMLA / FEMA Probes & DGGI GST Evasion Notices',
        rationale:
          'Screens for Enforcement Directorate inquiries, DGGI fake-invoice/ITC evasion raids, and Income Tax searches.',
        query: `${entityNames} ("Enforcement Directorate" OR "PMLA" OR "DGGI" OR "GST evasion" OR "Income Tax raid" OR "benami")`,
      },
      {
        id: 'cbi-sfio',
        category: 'ed_cbi',
        categoryLabel: 'ED / CBI News',
        registrySource: 'SFIO · CBI · NFRA',
        title: 'SFIO Investigations, NFRA Auditor Findings & CBI Inquiries',
        rationale:
          'Captures SFIO corporate fraud investigations, NFRA audit lapses, and CBI procurement/banking inquiries.',
        query: `${entityNames} ("SFIO" OR "NFRA" OR "CBI" OR "Economic Offences Wing" OR "accounting irregularities" OR "whistleblower")`,
      },
      // MCA21 - PE Deal Focus
      {
        id: 'mca21-registry',
        category: 'mca21',
        categoryLabel: 'MCA21 Corporate Records',
        registrySource: 'mca.gov.in · Corporate Filings',
        title: 'MCA21 Charge Registry, Auditor Resignations & Financials',
        rationale:
          'Reviews registered charges (CHG-1), MGT-7 ownership, statutory auditor resignations, and group subsidiaries.',
        query: identifier
          ? `(site:mca.gov.in OR site:zaubacorp.com OR site:tofler.in) (${entityNames} OR "${identifier}") (charges OR auditor OR director OR subsidiary)`
          : `(site:mca.gov.in OR site:zaubacorp.com OR site:tofler.in) ${entityNames} (charges OR auditor OR director OR subsidiary)`,
      },
      {
        id: 'mca21-disqualification',
        category: 'mca21',
        categoryLabel: 'MCA21 Corporate Records',
        registrySource: 'ROC · MCA21 Compliance',
        title: 'Related-Party Entities, Strike-Offs & Sec 164(2) Defaults',
        rationale:
          'Identifies dormant or struck-off group companies, ROC compounding penalties, and DIN disqualifications.',
        query: `${entityAll} ("164(2)" OR "STK-7" OR "struck off" OR "Registrar of Companies" OR "compounding" OR "related party")`,
      },
    ];
  } else if (investigationType === 'promoter_bg') {
    queries = [
      // SEBI - Promoter Background
      {
        id: 'sebi-orders',
        category: 'sebi',
        categoryLabel: 'SEBI Enforcement Orders',
        registrySource: 'sebi.gov.in',
        title: 'Individual Debarment, Market Ban & Insider Trading',
        rationale:
          'Checks whether the promoter/subject has been personally restrained from accessing securities markets or holding KMP roles.',
        query: `site:sebi.gov.in ${personOnly} (debarred OR restrained OR "insider trading" OR "PFUTP" OR "front running" OR "fit and proper")`,
      },
      {
        id: 'sebi-sat',
        category: 'sebi',
        categoryLabel: 'SEBI Enforcement Orders',
        registrySource: 'SAT · SEBI Enforcement',
        title: 'Promoter Shell Trading, Price Rigging & SAT Appeals',
        rationale:
          'Surfaces promoter-linked circular trading, preferential allotment violations, and SAT penalty confirmations.',
        query: `${entityNames} ("circular trading" OR "price manipulation" OR "SEBI penalty" OR "Securities Appellate Tribunal" OR "vanishing company")`,
      },
      // NCLT - Promoter Background
      {
        id: 'nclt-ibbi',
        category: 'nclt',
        categoryLabel: 'NCLT Insolvency Filings',
        registrySource: 'nclt.gov.in · ibbi.gov.in',
        title: 'Section 29A Disqualification & Personal Guarantor CIRP',
        rationale:
          'Checks IBC Section 95 personal guarantor insolvency and Section 29A promoter ineligibility findings.',
        query: `(site:nclt.gov.in OR site:ibbi.gov.in) ${entityAll} ("Section 95" OR "personal guarantor" OR "Section 29A" OR "Section 66" OR "fraudulent trading")`,
      },
      {
        id: 'nclt-nclat',
        category: 'nclt',
        categoryLabel: 'NCLT Insolvency Filings',
        registrySource: 'NCLT · NCLAT',
        title: 'Prior Failed Ventures & Undervalued / Preferential Acts',
        rationale:
          'Uncovers past corporate insolvencies led by the promoter and PUFE (preferential/undervalued/fraudulent) transaction orders.',
        query: `${personOnly} ("NCLT" OR "NCLAT") ("suspended director" OR "personal guarantor" OR "Section 43" OR "Section 66" OR "insolvency")`,
      },
      // e-Courts - Promoter Background
      {
        id: 'ecourts-kanoon',
        category: 'ecourts',
        categoryLabel: 'e-Courts Litigation',
        registrySource: 'indiankanoon.org',
        title: 'Criminal Petitions, Anticipatory Bail & Quashing Pleas',
        rationale:
          'Searches High Court & Supreme Court dockets for IPC 420/406 cheating, anticipatory bail, and Section 482 CrPC pleas.',
        query: `site:indiankanoon.org ${personOnly} ("420" OR "406" OR "anticipatory bail" OR "bail" OR "quashing" OR "FIR" OR "cheating")`,
      },
      {
        id: 'ecourts-ni138',
        category: 'ecourts',
        categoryLabel: 'e-Courts Litigation',
        registrySource: 'ecourts.gov.in · Magistrate Courts',
        title: 'Section 138 NI Act Warrants & Personal Civil Suits',
        rationale:
          'Identifies cheque dishonour complaints, non-bailable warrants, and personal recovery litigation on e-Courts.',
        query: `(site:ecourts.gov.in OR "Magistrate" OR "High Court") ${personOnly} ("138 NI Act" OR "cheque bounce" OR "warrant" OR "summons" OR "defamation")`,
      },
      // RBI - Promoter Background
      {
        id: 'rbi-cibil',
        category: 'rbi',
        categoryLabel: 'RBI Wilful Defaulters',
        registrySource: 'RBI · CIBIL · Bank Lists',
        title: 'Personal Wilful Defaulter & Non-Cooperative Borrower',
        rationale:
          'Screens RBI wilful defaulter classifications, CIBIL suit-filed promoter-guarantor records, and bank blacklists.',
        query: `${entityAll} ("wilful defaulter" OR "non-cooperative borrower" OR "personal guarantor" OR "suit filed" OR "CIBIL")`,
      },
      {
        id: 'rbi-drt',
        category: 'rbi',
        categoryLabel: 'RBI Wilful Defaulters',
        registrySource: 'Look Out Circular · DRT',
        title: 'Look Out Circulars (LOC), Passport Impoundment & DRT',
        rationale:
          'Searches for bank-initiated Look Out Circulars, DRT recovery certificates against the promoter, and wilful flight-risk flags.',
        query: `${personOnly} ("Look Out Circular" OR "LOC" OR "impound passport" OR "Debt Recovery Tribunal" OR "absconding")`,
      },
      // ED/CBI - Promoter Background
      {
        id: 'ed-pmla',
        category: 'ed_cbi',
        categoryLabel: 'ED / CBI News',
        registrySource: 'ED · PMLA · Customs / DRI',
        title: 'ED Arrests, PMLA Summons, Hawala & Black Money Act',
        rationale:
          'Targets Enforcement Directorate summons, arrests, DRI smuggling/under-invoicing notices, and offshore undisclosed asset probes.',
        query: `${entityNames} ("Enforcement Directorate" OR "PMLA" OR "ED summons" OR "hawala" OR "Black Money Act" OR "DRI")`,
      },
      {
        id: 'cbi-sfio',
        category: 'ed_cbi',
        categoryLabel: 'ED / CBI News',
        registrySource: 'CBI · EOW · Political Exposure',
        title: 'CBI / EOW Arrests, PEP Connections & Bribery FIRs',
        rationale:
          'Screens CBI/EOW criminal chargesheets, Prevention of Corruption Act cases, and politically exposed person (PEP) ties.',
        query: `${personOnly} ("CBI" OR "EOW" OR "arrested" OR "chargesheet" OR "Prevention of Corruption" OR "politically exposed" OR "MLA" OR "MP")`,
      },
      // MCA21 - Promoter Background
      {
        id: 'mca21-registry',
        category: 'mca21',
        categoryLabel: 'MCA21 Corporate Records',
        registrySource: 'mca.gov.in · DIN Network',
        title: 'Complete DIN Directorship History & Shell Associations',
        rationale:
          'Maps all past and present directorships linked to the promoter DIN across Indian corporate registries.',
        query: identifier
          ? `(site:mca.gov.in OR site:zaubacorp.com OR site:tofler.in OR site:thecompanycheck.com) (${personOnly} OR "${identifier}")`
          : `(site:mca.gov.in OR site:zaubacorp.com OR site:tofler.in OR site:thecompanycheck.com) ${personOnly} (DIN OR director OR associated)`,
      },
      {
        id: 'mca21-disqualification',
        category: 'mca21',
        categoryLabel: 'MCA21 Corporate Records',
        registrySource: 'ROC · MCA21 Defaulters',
        title: 'Section 164(2) Disqualification & Shell-Company STK-7 Lists',
        rationale:
          'Verifies whether the promoter DIN was deactivated or disqualified under Section 164(2) for non-filing or shell activity.',
        query: `${entityAll} ("disqualified director" OR "164(2)" OR "DIN deactivated" OR "shell company" OR "struck off" OR "STK-7")`,
      },
    ];
  } else {
    // litigation_asset — Litigation & Asset Tracing
    queries = [
      // SEBI - Litigation & Asset Tracing
      {
        id: 'sebi-orders',
        category: 'sebi',
        categoryLabel: 'SEBI Enforcement Orders',
        registrySource: 'sebi.gov.in · Recovery',
        title: 'SEBI Recovery Certificates, Bank & Demat Attachments',
        rationale:
          'Identifies SEBI Recovery Officer attachment proceedings against bank accounts, mutual funds, and immovable properties.',
        query: `site:sebi.gov.in ${entityAll} ("recovery certificate" OR "attachment" OR "bank account" OR "demat" OR "Recovery Officer" OR "disgorgement")`,
      },
      {
        id: 'sebi-sat',
        category: 'sebi',
        categoryLabel: 'SEBI Enforcement Orders',
        registrySource: 'SAT · SEBI Asset Freeze',
        title: 'Disgorgement Decrees & Impounding Orders',
        rationale:
          'Surfaces SEBI impounding orders, frozen escrow proceeds, and SAT stay/deposit conditions.',
        query: `${entityNames} ("disgorgement" OR "impounding order" OR "SEBI attachment" OR "frozen account" OR "unlawful gain")`,
      },
      // NCLT - Litigation & Asset Tracing
      {
        id: 'nclt-ibbi',
        category: 'nclt',
        categoryLabel: 'NCLT Insolvency Filings',
        registrySource: 'nclt.gov.in · ibbi.gov.in',
        title: 'Liquidation Estate, E-Auctions & Section 66 Clawbacks',
        rationale:
          'Traces corporate liquidation estates, asset e-auction notices, and resolution professional clawback applications.',
        query: `(site:nclt.gov.in OR site:ibbi.gov.in) ${entityAll} (liquidation OR "e-auction" OR "assets" OR "clawback" OR "Section 66" OR "valuation")`,
      },
      {
        id: 'nclt-nclat',
        category: 'nclt',
        categoryLabel: 'NCLT Insolvency Filings',
        registrySource: 'NCLT · NCLAT',
        title: 'Moratorium Lifting, Secured Creditor Enforcement & Decrees',
        rationale:
          'Locates NCLT/NCLAT orders concerning secured creditor collateral, leased asset repossessions, and status quo injunctions.',
        query: `${entityNames} ("NCLT" OR "NCLAT") ("secured creditor" OR "collateral" OR "moratorium" OR "status quo" OR "asset sale" OR "guarantor")`,
      },
      // e-Courts - Litigation & Asset Tracing
      {
        id: 'ecourts-kanoon',
        category: 'ecourts',
        categoryLabel: 'e-Courts Litigation',
        registrySource: 'indiankanoon.org',
        title: 'Execution Petitions, Order 38 Rule 5 Attachments & Awards',
        rationale:
          'Searches for execution decrees, attachment before judgment (Order 38 Rule 5 CPC), and Section 9/34/36 Arbitration Act orders.',
        query: `site:indiankanoon.org ${entityNames} ("execution petition" OR "Order 38 Rule 5" OR "attachment" OR "arbitral award" OR "Section 9" OR "injunction")`,
      },
      {
        id: 'ecourts-ni138',
        category: 'ecourts',
        categoryLabel: 'e-Courts Litigation',
        registrySource: 'ecourts.gov.in · High Courts',
        title: 'Property Title Suits, Lis Pendens & Recovery Decrees',
        rationale:
          'Surfaces immovable property encumbrances, specific performance suits, and decree-holder garnishee proceedings.',
        query: `(site:ecourts.gov.in OR "High Court" OR "Commercial Court") ${entityNames} ("decree" OR "garnishee" OR "immovable property" OR "lis pendens" OR "receiver")`,
      },
      // RBI - Litigation & Asset Tracing
      {
        id: 'rbi-cibil',
        category: 'rbi',
        categoryLabel: 'RBI Wilful Defaulters',
        registrySource: 'DRT · CERSAI · SARFAESI',
        title: 'SARFAESI Section 13(2) / 13(4) Possession & Auction Notices',
        rationale:
          'Traces bank possession notices, mortgaged land/factory e-auctions, and CERSAI security interest filings.',
        query: `${entityAll} ("SARFAESI" OR "13(2)" OR "13(4)" OR "possession notice" OR "e-auction" OR "mortgaged property" OR "CERSAI")`,
      },
      {
        id: 'rbi-drt',
        category: 'rbi',
        categoryLabel: 'RBI Wilful Defaulters',
        registrySource: 'DRT · DRAT · ARC',
        title: 'DRT Original Applications (OA), Recovery Certificates & ARCs',
        rationale:
          'Locates Debt Recovery Tribunal Original Applications, asset transfers to ARCs (NARCL/Edelweiss), and personal guarantor collateral.',
        query: `${entityNames} ("Debt Recovery Tribunal" OR "DRT" OR "DRAT" OR "Recovery Certificate" OR "Asset Reconstruction" OR "ARC")`,
      },
      // ED/CBI - Litigation & Asset Tracing
      {
        id: 'ed-pmla',
        category: 'ed_cbi',
        categoryLabel: 'ED / CBI News',
        registrySource: 'ED · PMLA · Benami',
        title: 'PMLA Section 5 Provisional Attachments & Benami Seizures',
        rationale:
          'Identifies immovable properties, bank balances, and shares attached by the ED under PMLA or Income Tax under the Benami Act.',
        query: `${entityNames} ("provisional attachment" OR "Section 5" OR "PMLA" OR "Benami" OR "confiscation" OR "seized properties" OR "attached assets")`,
      },
      {
        id: 'cbi-sfio',
        category: 'ed_cbi',
        categoryLabel: 'ED / CBI News',
        registrySource: 'EOW · SFIO · MPID',
        title: 'MPID / State Attachment Orders & Asset Freeze Petitions',
        rationale:
          'Screens state EOW / MPID Act property notifications, SFIO asset freeze applications, and criminal restitution orders.',
        query: `${entityNames} ("MPID" OR "EOW" OR "SFIO" OR "asset freeze" OR "attached property" OR "bank accounts frozen" OR "restitution")`,
      },
      // MCA21 - Litigation & Asset Tracing
      {
        id: 'mca21-registry',
        category: 'mca21',
        categoryLabel: 'MCA21 Corporate Records',
        registrySource: 'mca.gov.in · Index of Charges',
        title: 'MCA21 Open Charges (CHG-1), Mortgages & Hypothecation',
        rationale:
          'Maps all active bank/NBFC charges, hypothecated receivables, and mortgaged immovable assets on MCA21.',
        query: identifier
          ? `(site:mca.gov.in OR site:zaubacorp.com OR site:tofler.in) (${entityNames} OR "${identifier}") ("charges" OR "hypothecation" OR "mortgage" OR "satisfied" OR "open charge")`
          : `(site:mca.gov.in OR site:zaubacorp.com OR site:tofler.in) ${entityNames} ("charges" OR "hypothecation" OR "mortgage" OR "open charge")`,
      },
      {
        id: 'mca21-disqualification',
        category: 'mca21',
        categoryLabel: 'MCA21 Corporate Records',
        registrySource: 'MCA21 · Related Entities',
        title: 'Asset-Holding SPVs, Common Addresses & Subsidiary Web',
        rationale:
          'Identifies sister concerns, real estate SPVs, and common registered office addresses used to ring-fence assets.',
        query: `${entityAll} ("registered office" OR "subsidiary" OR "holding company" OR "associate company" OR "SPV" OR "CIN")`,
      },
    ];
  }

  return queries.map((item) => ({
    ...item,
    url: googleSearchUrl(item.query),
  }));
}
