export type OsintCategoryId =
  | 'sebi'
  | 'nclt'
  | 'ecourts'
  | 'rbi'
  | 'ed_cbi'
  | 'mca21';

export type InvestigationType =
  | 'pre_deal_pe'
  | 'promoter_bg'
  | 'litigation_asset';

export type RiskRating = 'Clear' | 'Low' | 'Medium' | 'High';

export type RiskDimensionScore = 0 | 1 | 2 | 3;

export interface RiskScoringMatrix {
  corporateGovernance: RiskDimensionScore;
  regulatoryCompliance: RiskDimensionScore;
  litigationInsolvency: RiskDimensionScore;
  adverseMediaEnforcement: RiskDimensionScore;
}

export type SourceReliability =
  | 'Primary Regulatory'
  | 'Reputable Media'
  | 'Unverified';

export interface SourceCitation {
  id: string;
  title: string;
  url: string;
  dateAccessed: string;
  reliability: SourceReliability;
}

export interface EntityDirectorLink {
  id: string;
  companyName: string;
  directorName: string;
  din: string;
  registeredAddress: string;
}

export interface InvestigationSubject {
  subjectName: string;
  companyName: string;
  dinCin: string;
}

export interface OsintQueryItem {
  id: string;
  category: OsintCategoryId;
  categoryLabel: string;
  registrySource: string;
  title: string;
  rationale: string;
  query: string;
  url: string;
}

export interface AnalystNotes {
  caseReference: string;
  analystName: string;
  riskRating: RiskRating;
  riskScores: RiskScoringMatrix;
  corporateBackground: string;
  regulatoryLitigationRedFlags: string;
  adverseMediaFindings: string;
  citations: SourceCitation[];
}

export interface DossierRecord {
  id: string;
  subject: InvestigationSubject;
  investigationType: InvestigationType;
  notes: AnalystNotes;
  reviewedLinkIds: string[];
  entityLinks: EntityDirectorLink[];
  createdAt: string;
  updatedAt: string;
}
